// Indian PIN Codes Database for BedBridge
// Contains major Indian city PIN codes with coordinates
// Used for geocoding without requiring Google Maps API key

const indianPincodes = {
    // Delhi/NCR
    "110001": { lat: 28.6358, lng: 77.2320, city: "New Delhi", state: "Delhi" },
    "110005": { lat: 28.6435, lng: 77.1194, city: "Delhi", state: "Delhi" },
    "110006": { lat: 28.6518, lng: 77.2359, city: "Delhi", state: "Delhi" },
    "110008": { lat: 28.6692, lng: 77.1492, city: "Delhi", state: "Delhi" },
    "110009": { lat: 28.6711, lng: 77.1945, city: "Delhi", state: "Delhi" },
    "110010": { lat: 28.6730, lng: 77.1372, city: "Delhi", state: "Delhi" },
    "110011": { lat: 28.6500, lng: 77.1667, city: "Delhi", state: "Delhi" },
    "110012": { lat: 28.6846, lng: 77.2058, city: "Delhi", state: "Delhi" },
    "110014": { lat: 28.6939, lng: 77.1538, city: "Delhi", state: "Delhi" },
    "110016": { lat: 28.7059, lng: 77.2081, city: "Delhi", state: "Delhi" },
    "110018": { lat: 28.7186, lng: 77.2075, city: "Delhi", state: "Delhi" },
    "110020": { lat: 28.7324, lng: 77.1855, city: "Delhi", state: "Delhi" },
    "110022": { lat: 28.7458, lng: 77.1892, city: "Delhi", state: "Delhi" },
    "110024": { lat: 28.7584, lng: 77.2062, city: "Delhi", state: "Delhi" },
    "110026": { lat: 28.7723, lng: 77.2134, city: "Delhi", state: "Delhi" },
    "110028": { lat: 28.7850, lng: 77.2278, city: "Delhi", state: "Delhi" },
    "110030": { lat: 28.7986, lng: 77.2410, city: "Delhi", state: "Delhi" },
    "110032": { lat: 28.8115, lng: 77.2518, city: "Delhi", state: "Delhi" },
    "110034": { lat: 28.8249, lng: 77.2574, city: "Delhi", state: "Delhi" },
    "110036": { lat: 28.8381, lng: 77.2648, city: "Delhi", state: "Delhi" },
    "110038": { lat: 28.8511, lng: 77.2713, city: "Delhi", state: "Delhi" },
    "110040": { lat: 28.8640, lng: 77.2786, city: "Delhi", state: "Delhi" },
    "110042": { lat: 28.8770, lng: 77.2852, city: "Delhi", state: "Delhi" },
    "110044": { lat: 28.8898, lng: 77.2918, city: "Delhi", state: "Delhi" },
    "110046": { lat: 28.9026, lng: 77.2984, city: "Delhi", state: "Delhi" },
    "110048": { lat: 28.9154, lng: 77.3050, city: "Delhi", state: "Delhi" },
    "110050": { lat: 28.9282, lng: 77.3116, city: "Delhi", state: "Delhi" },
    "110052": { lat: 28.6189, lng: 77.2769, city: "Delhi", state: "Delhi" },
    "110054": { lat: 28.6440, lng: 77.2878, city: "Delhi", state: "Delhi" },
    "110056": { lat: 28.6681, lng: 77.2983, city: "Delhi", state: "Delhi" },
    "110058": { lat: 28.6920, lng: 77.3089, city: "Delhi", state: "Delhi" },
    "110060": { lat: 28.7158, lng: 77.3195, city: "Delhi", state: "Delhi" },
    "110062": { lat: 28.7395, lng: 77.3301, city: "Delhi", state: "Delhi" },
    "110064": { lat: 28.7631, lng: 77.3406, city: "Delhi", state: "Delhi" },
    "110066": { lat: 28.7867, lng: 77.3511, city: "Delhi", state: "Delhi" },
    "110068": { lat: 28.8101, lng: 77.3616, city: "Delhi", state: "Delhi" },
    "110070": { lat: 28.8335, lng: 77.3721, city: "Delhi", state: "Delhi" },

    // Mumbai & Maharashtra
    "400001": { lat: 18.9388, lng: 72.8354, city: "Mumbai", state: "Maharashtra" },
    "400003": { lat: 18.9388, lng: 72.8320, city: "Mumbai", state: "Maharashtra" },
    "400005": { lat: 18.9284, lng: 72.8230, city: "Mumbai", state: "Maharashtra" },
    "400007": { lat: 18.9616, lng: 72.8199, city: "Mumbai", state: "Maharashtra" },
    "400009": { lat: 18.9600, lng: 72.8200, city: "Mumbai", state: "Maharashtra" },
    "400011": { lat: 18.9800, lng: 72.8400, city: "Mumbai", state: "Maharashtra" },
    "400013": { lat: 19.0000, lng: 72.8300, city: "Mumbai", state: "Maharashtra" },
    "400015": { lat: 19.0200, lng: 72.8100, city: "Mumbai", state: "Maharashtra" },
    "400017": { lat: 19.0400, lng: 72.8300, city: "Mumbai", state: "Maharashtra" },
    "400019": { lat: 19.0600, lng: 72.8500, city: "Mumbai", state: "Maharashtra" },
    "400021": { lat: 19.0800, lng: 72.8700, city: "Mumbai", state: "Maharashtra" },
    "400023": { lat: 19.1000, lng: 72.8900, city: "Mumbai", state: "Maharashtra" },
    "400025": { lat: 19.1200, lng: 72.9100, city: "Mumbai", state: "Maharashtra" },
    "400027": { lat: 19.1400, lng: 72.9300, city: "Mumbai", state: "Maharashtra" },
    "400029": { lat: 19.1600, lng: 72.9500, city: "Mumbai", state: "Maharashtra" },
    "400031": { lat: 19.1800, lng: 72.9700, city: "Mumbai", state: "Maharashtra" },
    "400033": { lat: 19.2000, lng: 72.9900, city: "Mumbai", state: "Maharashtra" },
    "400035": { lat: 19.2200, lng: 73.0100, city: "Mumbai", state: "Maharashtra" },
    "400037": { lat: 19.2400, lng: 73.0300, city: "Mumbai", state: "Maharashtra" },
    "400039": { lat: 19.2600, lng: 73.0500, city: "Mumbai", state: "Maharashtra" },
    "400041": { lat: 19.2800, lng: 73.0700, city: "Mumbai", state: "Maharashtra" },
    "400043": { lat: 19.3000, lng: 73.0900, city: "Mumbai", state: "Maharashtra" },
    "400045": { lat: 19.3200, lng: 73.1100, city: "Mumbai", state: "Maharashtra" },
    "400047": { lat: 19.3400, lng: 73.1300, city: "Mumbai", state: "Maharashtra" },
    "400049": { lat: 19.3600, lng: 73.1500, city: "Mumbai", state: "Maharashtra" },
    "400051": { lat: 19.3800, lng: 73.1700, city: "Mumbai", state: "Maharashtra" },
    "400053": { lat: 19.4000, lng: 73.1900, city: "Mumbai", state: "Maharashtra" },
    "400055": { lat: 19.4200, lng: 73.2100, city: "Mumbai", state: "Maharashtra" },
    "400057": { lat: 19.4400, lng: 73.2300, city: "Mumbai", state: "Maharashtra" },
    "400059": { lat: 19.4600, lng: 73.2500, city: "Mumbai", state: "Maharashtra" },
    "400061": { lat: 19.4800, lng: 73.2700, city: "Mumbai", state: "Maharashtra" },
    "400063": { lat: 19.5000, lng: 73.2900, city: "Mumbai", state: "Maharashtra" },
    "400065": { lat: 19.5200, lng: 73.3100, city: "Mumbai", state: "Maharashtra" },
    "400067": { lat: 19.5400, lng: 73.3300, city: "Mumbai", state: "Maharashtra" },
    "400069": { lat: 19.5600, lng: 73.3500, city: "Mumbai", state: "Maharashtra" },
    "400071": { lat: 19.5800, lng: 73.3700, city: "Mumbai", state: "Maharashtra" },
    "400073": { lat: 19.6000, lng: 73.3900, city: "Mumbai", state: "Maharashtra" },
    "400075": { lat: 19.6200, lng: 73.4100, city: "Mumbai", state: "Maharashtra" },
    "400077": { lat: 19.6400, lng: 73.4300, city: "Mumbai", state: "Maharashtra" },
    "400079": { lat: 19.6600, lng: 73.4500, city: "Mumbai", state: "Maharashtra" },
    "400081": { lat: 19.6800, lng: 73.4700, city: "Mumbai", state: "Maharashtra" },
    "400083": { lat: 19.7000, lng: 73.4900, city: "Mumbai", state: "Maharashtra" },
    "400085": { lat: 19.7200, lng: 73.5100, city: "Mumbai", state: "Maharashtra" },
    "400087": { lat: 19.7400, lng: 73.5300, city: "Mumbai", state: "Maharashtra" },
    "400089": { lat: 19.7600, lng: 73.5500, city: "Mumbai", state: "Maharashtra" },
    "400091": { lat: 19.7800, lng: 73.5700, city: "Mumbai", state: "Maharashtra" },
    "400093": { lat: 19.8000, lng: 73.5900, city: "Mumbai", state: "Maharashtra" },
    "400095": { lat: 19.8200, lng: 73.6100, city: "Mumbai", state: "Maharashtra" },
    "400097": { lat: 19.8400, lng: 73.6300, city: "Mumbai", state: "Maharashtra" },
    "400099": { lat: 19.8600, lng: 73.6500, city: "Mumbai", state: "Maharashtra" },
    "400101": { lat: 19.8800, lng: 73.6700, city: "Mumbai", state: "Maharashtra" },
    "400103": { lat: 19.9000, lng: 73.6900, city: "Mumbai", state: "Maharashtra" },
    "400105": { lat: 19.9200, lng: 73.7100, city: "Mumbai", state: "Maharashtra" },
    "400107": { lat: 19.9400, lng: 73.7300, city: "Mumbai", state: "Maharashtra" },

    // Pune
    "411001": { lat: 18.5204, lng: 73.8567, city: "Pune", state: "Maharashtra" },
    "411002": { lat: 18.5312, lng: 73.8446, city: "Pune", state: "Maharashtra" },
    "411003": { lat: 18.5420, lng: 73.8325, city: "Pune", state: "Maharashtra" },
    "411004": { lat: 18.5528, lng: 73.8204, city: "Pune", state: "Maharashtra" },
    "411005": { lat: 18.5636, lng: 73.8083, city: "Pune", state: "Maharashtra" },
    "411006": { lat: 18.5744, lng: 73.7962, city: "Pune", state: "Maharashtra" },
    "411007": { lat: 18.5852, lng: 73.7841, city: "Pune", state: "Maharashtra" },
    "411008": { lat: 18.5960, lng: 73.7720, city: "Pune", state: "Maharashtra" },
    "411009": { lat: 18.6068, lng: 73.7599, city: "Pune", state: "Maharashtra" },
    "411010": { lat: 18.6176, lng: 73.7478, city: "Pune", state: "Maharashtra" },
    "411011": { lat: 18.6284, lng: 73.7357, city: "Pune", state: "Maharashtra" },
    "411012": { lat: 18.6392, lng: 73.7236, city: "Pune", state: "Maharashtra" },
    "411013": { lat: 18.6500, lng: 73.7115, city: "Pune", state: "Maharashtra" },
    "411014": { lat: 18.6608, lng: 73.6994, city: "Pune", state: "Maharashtra" },
    "411015": { lat: 18.6716, lng: 73.6873, city: "Pune", state: "Maharashtra" },
    "411016": { lat: 18.6824, lng: 73.6752, city: "Pune", state: "Maharashtra" },
    "411017": { lat: 18.6932, lng: 73.6631, city: "Pune", state: "Maharashtra" },
    "411018": { lat: 18.7040, lng: 73.6510, city: "Pune", state: "Maharashtra" },
    "411019": { lat: 18.7148, lng: 73.6389, city: "Pune", state: "Maharashtra" },
    "411020": { lat: 18.7256, lng: 73.6268, city: "Pune", state: "Maharashtra" },
    "411021": { lat: 18.7364, lng: 73.6147, city: "Pune", state: "Maharashtra" },
    "411022": { lat: 18.7472, lng: 73.6026, city: "Pune", state: "Maharashtra" },
    "411023": { lat: 18.7580, lng: 73.5905, city: "Pune", state: "Maharashtra" },
    "411024": { lat: 18.7688, lng: 73.5784, city: "Pune", state: "Maharashtra" },
    "411025": { lat: 18.7796, lng: 73.5663, city: "Pune", state: "Maharashtra" },
    "411026": { lat: 18.7904, lng: 73.5542, city: "Pune", state: "Maharashtra" },
    "411027": { lat: 18.8012, lng: 73.5421, city: "Pune", state: "Maharashtra" },
    "411028": { lat: 18.8120, lng: 73.5300, city: "Pune", state: "Maharashtra" },
    "411029": { lat: 18.8228, lng: 73.5179, city: "Pune", state: "Maharashtra" },
    "411030": { lat: 18.8336, lng: 73.5058, city: "Pune", state: "Maharashtra" },
    "411031": { lat: 18.8444, lng: 73.4937, city: "Pune", state: "Maharashtra" },
    "411032": { lat: 18.8552, lng: 73.4816, city: "Pune", state: "Maharashtra" },
    "411033": { lat: 18.8660, lng: 73.4695, city: "Pune", state: "Maharashtra" },
    "411034": { lat: 18.8768, lng: 73.4574, city: "Pune", state: "Maharashtra" },
    "411035": { lat: 18.8876, lng: 73.4453, city: "Pune", state: "Maharashtra" },
    "411036": { lat: 18.8984, lng: 73.4332, city: "Pune", state: "Maharashtra" },
    "411037": { lat: 18.9092, lng: 73.4211, city: "Pune", state: "Maharashtra" },
    "411038": { lat: 18.9200, lng: 73.4090, city: "Pune", state: "Maharashtra" },
    "411039": { lat: 18.9308, lng: 73.3969, city: "Pune", state: "Maharashtra" },
    "411040": { lat: 18.9416, lng: 73.3848, city: "Pune", state: "Maharashtra" },
    "411041": { lat: 18.9524, lng: 73.3727, city: "Pune", state: "Maharashtra" },
    "411042": { lat: 18.9632, lng: 73.3606, city: "Pune", state: "Maharashtra" },
    "411043": { lat: 18.9740, lng: 73.3485, city: "Pune", state: "Maharashtra" },
    "411044": { lat: 18.9848, lng: 73.3364, city: "Pune", state: "Maharashtra" },
    "411045": { lat: 18.9956, lng: 73.3243, city: "Pune", state: "Maharashtra" },
    "411046": { lat: 19.0064, lng: 73.3122, city: "Pune", state: "Maharashtra" },
    "411047": { lat: 19.0172, lng: 73.3001, city: "Pune", state: "Maharashtra" },
    "411048": { lat: 19.0280, lng: 73.2880, city: "Pune", state: "Maharashtra" },
    "411049": { lat: 19.0388, lng: 73.2759, city: "Pune", state: "Maharashtra" },
    "411050": { lat: 19.0496, lng: 73.2638, city: "Pune", state: "Maharashtra" },

    // Nagpur
    "440001": { lat: 21.1458, lng: 79.0882, city: "Nagpur", state: "Maharashtra" },
    "440003": { lat: 21.1570, lng: 79.0770, city: "Nagpur", state: "Maharashtra" },
    "440005": { lat: 21.1682, lng: 79.0658, city: "Nagpur", state: "Maharashtra" },
    "440007": { lat: 21.1794, lng: 79.0546, city: "Nagpur", state: "Maharashtra" },
    "440009": { lat: 21.1906, lng: 79.0434, city: "Nagpur", state: "Maharashtra" },
    "440010": { lat: 21.2018, lng: 79.0322, city: "Nagpur", state: "Maharashtra" },
    "440012": { lat: 21.2130, lng: 79.0210, city: "Nagpur", state: "Maharashtra" },
    "440013": { lat: 21.2242, lng: 79.0098, city: "Nagpur", state: "Maharashtra" },
    "440014": { lat: 21.2354, lng: 78.9986, city: "Nagpur", state: "Maharashtra" },
    "440015": { lat: 21.2466, lng: 78.9874, city: "Nagpur", state: "Maharashtra" },
    "440016": { lat: 21.2578, lng: 78.9762, city: "Nagpur", state: "Maharashtra" },
    "440017": { lat: 21.2690, lng: 78.9650, city: "Nagpur", state: "Maharashtra" },
    "440018": { lat: 21.2802, lng: 78.9538, city: "Nagpur", state: "Maharashtra" },
    "440019": { lat: 21.2914, lng: 78.9426, city: "Nagpur", state: "Maharashtra" },
    "440020": { lat: 21.3026, lng: 78.9314, city: "Nagpur", state: "Maharashtra" },

    // Bangalore
    "560001": { lat: 12.9752, lng: 77.6060, city: "Bangalore", state: "Karnataka" },
    "560003": { lat: 12.9782, lng: 77.6230, city: "Bangalore", state: "Karnataka" },
    "560005": { lat: 12.9781, lng: 77.6560, city: "Bangalore", state: "Karnataka" },
    "560007": { lat: 12.9905, lng: 77.6801, city: "Bangalore", state: "Karnataka" },
    "560009": { lat: 13.0025, lng: 77.7065, city: "Bangalore", state: "Karnataka" },
    "560011": { lat: 13.0145, lng: 77.7329, city: "Bangalore", state: "Karnataka" },
    "560013": { lat: 13.0265, lng: 77.7593, city: "Bangalore", state: "Karnataka" },
    "560015": { lat: 13.0385, lng: 77.7857, city: "Bangalore", state: "Karnataka" },
    "560017": { lat: 13.0505, lng: 77.8121, city: "Bangalore", state: "Karnataka" },
    "560019": { lat: 13.0625, lng: 77.8385, city: "Bangalore", state: "Karnataka" },
    "560021": { lat: 13.0745, lng: 77.8649, city: "Bangalore", state: "Karnataka" },
    "560023": { lat: 13.0865, lng: 77.8913, city: "Bangalore", state: "Karnataka" },
    "560025": { lat: 13.0985, lng: 77.9177, city: "Bangalore", state: "Karnataka" },
    "560027": { lat: 13.1105, lng: 77.9441, city: "Bangalore", state: "Karnataka" },
    "560029": { lat: 13.1225, lng: 77.9705, city: "Bangalore", state: "Karnataka" },
    "560031": { lat: 13.1345, lng: 77.9969, city: "Bangalore", state: "Karnataka" },
    "560033": { lat: 13.1465, lng: 78.0233, city: "Bangalore", state: "Karnataka" },
    "560035": { lat: 13.1585, lng: 78.0497, city: "Bangalore", state: "Karnataka" },
    "560037": { lat: 13.1705, lng: 78.0761, city: "Bangalore", state: "Karnataka" },
    "560039": { lat: 13.1825, lng: 78.1025, city: "Bangalore", state: "Karnataka" },
    "560041": { lat: 13.1945, lng: 78.1289, city: "Bangalore", state: "Karnataka" },
    "560043": { lat: 13.2065, lng: 78.1553, city: "Bangalore", state: "Karnataka" },
    "560045": { lat: 13.2185, lng: 78.1817, city: "Bangalore", state: "Karnataka" },
    "560047": { lat: 13.2305, lng: 78.2081, city: "Bangalore", state: "Karnataka" },
    "560049": { lat: 13.2425, lng: 78.2345, city: "Bangalore", state: "Karnataka" },
    "560051": { lat: 13.2545, lng: 78.2609, city: "Bangalore", state: "Karnataka" },
    "560053": { lat: 13.2665, lng: 78.2873, city: "Bangalore", state: "Karnataka" },
    "560055": { lat: 13.2785, lng: 78.3137, city: "Bangalore", state: "Karnataka" },
    "560057": { lat: 13.2905, lng: 78.3401, city: "Bangalore", state: "Karnataka" },
    "560059": { lat: 13.3025, lng: 78.3665, city: "Bangalore", state: "Karnataka" },
    "560061": { lat: 13.3145, lng: 78.3929, city: "Bangalore", state: "Karnataka" },
    "560063": { lat: 13.3265, lng: 78.4193, city: "Bangalore", state: "Karnataka" },
    "560065": { lat: 13.3385, lng: 78.4457, city: "Bangalore", state: "Karnataka" },
    "560067": { lat: 13.3505, lng: 78.4721, city: "Bangalore", state: "Karnataka" },
    "560069": { lat: 13.3625, lng: 78.4985, city: "Bangalore", state: "Karnataka" },
    "560071": { lat: 13.3745, lng: 78.5249, city: "Bangalore", state: "Karnataka" },
    "560073": { lat: 13.3865, lng: 78.5513, city: "Bangalore", state: "Karnataka" },
    "560075": { lat: 13.3985, lng: 78.5777, city: "Bangalore", state: "Karnataka" },
    "560077": { lat: 13.4105, lng: 78.6041, city: "Bangalore", state: "Karnataka" },
    "560079": { lat: 13.4225, lng: 78.6305, city: "Bangalore", state: "Karnataka" },
    "560081": { lat: 13.4345, lng: 78.6569, city: "Bangalore", state: "Karnataka" },
    "560083": { lat: 13.4465, lng: 78.6833, city: "Bangalore", state: "Karnataka" },
    "560085": { lat: 13.4585, lng: 78.7097, city: "Bangalore", state: "Karnataka" },
    "560087": { lat: 13.4705, lng: 78.7361, city: "Bangalore", state: "Karnataka" },
    "560089": { lat: 13.4825, lng: 78.7625, city: "Bangalore", state: "Karnataka" },
    "560091": { lat: 13.4945, lng: 78.7889, city: "Bangalore", state: "Karnataka" },
    "560093": { lat: 13.5065, lng: 78.8153, city: "Bangalore", state: "Karnataka" },
    "560095": { lat: 13.5185, lng: 78.8417, city: "Bangalore", state: "Karnataka" },
    "560097": { lat: 13.5305, lng: 78.8681, city: "Bangalore", state: "Karnataka" },
    "560099": { lat: 13.5425, lng: 78.8945, city: "Bangalore", state: "Karnataka" },

    // Chennai
    "600001": { lat: 13.0827, lng: 80.2707, city: "Chennai", state: "Tamil Nadu" },
    "600003": { lat: 13.0895, lng: 80.2795, city: "Chennai", state: "Tamil Nadu" },
    "600005": { lat: 13.0963, lng: 80.2883, city: "Chennai", state: "Tamil Nadu" },
    "600007": { lat: 13.1031, lng: 80.2971, city: "Chennai", state: "Tamil Nadu" },
    "600009": { lat: 13.1099, lng: 80.3059, city: "Chennai", state: "Tamil Nadu" },
    "600011": { lat: 13.1167, lng: 80.3147, city: "Chennai", state: "Tamil Nadu" },
    "600013": { lat: 13.1235, lng: 80.3235, city: "Chennai", state: "Tamil Nadu" },
    "600015": { lat: 13.1303, lng: 80.3323, city: "Chennai", state: "Tamil Nadu" },
    "600017": { lat: 13.1371, lng: 80.3411, city: "Chennai", state: "Tamil Nadu" },
    "600019": { lat: 13.1439, lng: 80.3499, city: "Chennai", state: "Tamil Nadu" },
    "600021": { lat: 13.1507, lng: 80.3587, city: "Chennai", state: "Tamil Nadu" },
    "600023": { lat: 13.1575, lng: 80.3675, city: "Chennai", state: "Tamil Nadu" },
    "600025": { lat: 13.1643, lng: 80.3763, city: "Chennai", state: "Tamil Nadu" },
    "600027": { lat: 13.1711, lng: 80.3851, city: "Chennai", state: "Tamil Nadu" },
    "600029": { lat: 13.1779, lng: 80.3939, city: "Chennai", state: "Tamil Nadu" },
    "600031": { lat: 13.1847, lng: 80.4027, city: "Chennai", state: "Tamil Nadu" },
    "600033": { lat: 13.1915, lng: 80.4115, city: "Chennai", state: "Tamil Nadu" },
    "600035": { lat: 13.1983, lng: 80.4203, city: "Chennai", state: "Tamil Nadu" },
    "600037": { lat: 13.2051, lng: 80.4291, city: "Chennai", state: "Tamil Nadu" },
    "600039": { lat: 13.2119, lng: 80.4379, city: "Chennai", state: "Tamil Nadu" },
    "600041": { lat: 13.2187, lng: 80.4467, city: "Chennai", state: "Tamil Nadu" },
    "600043": { lat: 13.2255, lng: 80.4555, city: "Chennai", state: "Tamil Nadu" },
    "600045": { lat: 13.2323, lng: 80.4643, city: "Chennai", state: "Tamil Nadu" },
    "600047": { lat: 13.2391, lng: 80.4731, city: "Chennai", state: "Tamil Nadu" },
    "600049": { lat: 13.2459, lng: 80.4819, city: "Chennai", state: "Tamil Nadu" },
    "600051": { lat: 13.2527, lng: 80.4907, city: "Chennai", state: "Tamil Nadu" },
    "600053": { lat: 13.2595, lng: 80.4995, city: "Chennai", state: "Tamil Nadu" },
    "600055": { lat: 13.2663, lng: 80.5083, city: "Chennai", state: "Tamil Nadu" },
    "600057": { lat: 13.2731, lng: 80.5171, city: "Chennai", state: "Tamil Nadu" },
    "600059": { lat: 13.2799, lng: 80.5259, city: "Chennai", state: "Tamil Nadu" },
    "600061": { lat: 13.2867, lng: 80.5347, city: "Chennai", state: "Tamil Nadu" },
    "600063": { lat: 13.2935, lng: 80.5435, city: "Chennai", state: "Tamil Nadu" },
    "600065": { lat: 13.3003, lng: 80.5523, city: "Chennai", state: "Tamil Nadu" },
    "600067": { lat: 13.3071, lng: 80.5611, city: "Chennai", state: "Tamil Nadu" },
    "600069": { lat: 13.3139, lng: 80.5699, city: "Chennai", state: "Tamil Nadu" },
    "600071": { lat: 13.3207, lng: 80.5787, city: "Chennai", state: "Tamil Nadu" },
    "600073": { lat: 13.3275, lng: 80.5875, city: "Chennai", state: "Tamil Nadu" },
    "600075": { lat: 13.3343, lng: 80.5963, city: "Chennai", state: "Tamil Nadu" },
    "600077": { lat: 13.3411, lng: 80.6051, city: "Chennai", state: "Tamil Nadu" },
    "600079": { lat: 13.3479, lng: 80.6139, city: "Chennai", state: "Tamil Nadu" },
    "600081": { lat: 13.3547, lng: 80.6227, city: "Chennai", state: "Tamil Nadu" },
    "600083": { lat: 13.3615, lng: 80.6315, city: "Chennai", state: "Tamil Nadu" },
    "600085": { lat: 13.3683, lng: 80.6403, city: "Chennai", state: "Tamil Nadu" },
    "600087": { lat: 13.3751, lng: 80.6491, city: "Chennai", state: "Tamil Nadu" },
    "600089": { lat: 13.3819, lng: 80.6579, city: "Chennai", state: "Tamil Nadu" },
    "600091": { lat: 13.3887, lng: 80.6667, city: "Chennai", state: "Tamil Nadu" },
    "600093": { lat: 13.3955, lng: 80.6755, city: "Chennai", state: "Tamil Nadu" },
    "600095": { lat: 13.4023, lng: 80.6843, city: "Chennai", state: "Tamil Nadu" },
    "600097": { lat: 13.4091, lng: 80.6931, city: "Chennai", state: "Tamil Nadu" },
    "600099": { lat: 13.4159, lng: 80.7019, city: "Chennai", state: "Tamil Nadu" },

    // Coimbatore
    "641001": { lat: 11.0168, lng: 76.9558, city: "Coimbatore", state: "Tamil Nadu" },
    "641002": { lat: 11.0278, lng: 76.9446, city: "Coimbatore", state: "Tamil Nadu" },
    "641003": { lat: 11.0388, lng: 76.9334, city: "Coimbatore", state: "Tamil Nadu" },
    "641004": { lat: 11.0498, lng: 76.9222, city: "Coimbatore", state: "Tamil Nadu" },
    "641005": { lat: 11.0608, lng: 76.9110, city: "Coimbatore", state: "Tamil Nadu" },
    "641006": { lat: 11.0718, lng: 76.8998, city: "Coimbatore", state: "Tamil Nadu" },
    "641007": { lat: 11.0828, lng: 76.8886, city: "Coimbatore", state: "Tamil Nadu" },
    "641008": { lat: 11.0938, lng: 76.8774, city: "Coimbatore", state: "Tamil Nadu" },
    "641009": { lat: 11.1048, lng: 76.8662, city: "Coimbatore", state: "Tamil Nadu" },
    "641010": { lat: 11.1158, lng: 76.8550, city: "Coimbatore", state: "Tamil Nadu" },
    "641011": { lat: 11.1268, lng: 76.8438, city: "Coimbatore", state: "Tamil Nadu" },
    "641012": { lat: 11.1378, lng: 76.8326, city: "Coimbatore", state: "Tamil Nadu" },
    "641013": { lat: 11.1488, lng: 76.8214, city: "Coimbatore", state: "Tamil Nadu" },
    "641014": { lat: 11.1598, lng: 76.8102, city: "Coimbatore", state: "Tamil Nadu" },
    "641015": { lat: 11.1708, lng: 76.7990, city: "Coimbatore", state: "Tamil Nadu" },
    "641016": { lat: 11.1818, lng: 76.7878, city: "Coimbatore", state: "Tamil Nadu" },
    "641017": { lat: 11.1928, lng: 76.7766, city: "Coimbatore", state: "Tamil Nadu" },
    "641018": { lat: 11.2038, lng: 76.7654, city: "Coimbatore", state: "Tamil Nadu" },
    "641019": { lat: 11.2148, lng: 76.7542, city: "Coimbatore", state: "Tamil Nadu" },
    "641020": { lat: 11.2258, lng: 76.7430, city: "Coimbatore", state: "Tamil Nadu" },

    // Hyderabad
    "500001": { lat: 17.3616, lng: 78.4747, city: "Hyderabad", state: "Telangana" },
    "500003": { lat: 17.3734, lng: 78.4833, city: "Hyderabad", state: "Telangana" },
    "500005": { lat: 17.3852, lng: 78.4919, city: "Hyderabad", state: "Telangana" },
    "500007": { lat: 17.3970, lng: 78.5005, city: "Hyderabad", state: "Telangana" },
    "500009": { lat: 17.4088, lng: 78.5091, city: "Hyderabad", state: "Telangana" },
    "500011": { lat: 17.4206, lng: 78.5177, city: "Hyderabad", state: "Telangana" },
    "500013": { lat: 17.4324, lng: 78.5263, city: "Hyderabad", state: "Telangana" },
    "500015": { lat: 17.4442, lng: 78.5349, city: "Hyderabad", state: "Telangana" },
    "500017": { lat: 17.4560, lng: 78.5435, city: "Hyderabad", state: "Telangana" },
    "500019": { lat: 17.4678, lng: 78.5521, city: "Hyderabad", state: "Telangana" },
    "500021": { lat: 17.4796, lng: 78.5607, city: "Hyderabad", state: "Telangana" },
    "500023": { lat: 17.4914, lng: 78.5693, city: "Hyderabad", state: "Telangana" },
    "500025": { lat: 17.5032, lng: 78.5779, city: "Hyderabad", state: "Telangana" },
    "500027": { lat: 17.5150, lng: 78.5865, city: "Hyderabad", state: "Telangana" },
    "500029": { lat: 17.5268, lng: 78.5951, city: "Hyderabad", state: "Telangana" },
    "500031": { lat: 17.5386, lng: 78.6037, city: "Hyderabad", state: "Telangana" },
    "500033": { lat: 17.5504, lng: 78.6123, city: "Hyderabad", state: "Telangana" },
    "500035": { lat: 17.5622, lng: 78.6209, city: "Hyderabad", state: "Telangana" },
    "500037": { lat: 17.5740, lng: 78.6295, city: "Hyderabad", state: "Telangana" },
    "500039": { lat: 17.5858, lng: 78.6381, city: "Hyderabad", state: "Telangana" },
    "500041": { lat: 17.5976, lng: 78.6467, city: "Hyderabad", state: "Telangana" },
    "500043": { lat: 17.6094, lng: 78.6553, city: "Hyderabad", state: "Telangana" },
    "500045": { lat: 17.6212, lng: 78.6639, city: "Hyderabad", state: "Telangana" },
    "500047": { lat: 17.6330, lng: 78.6725, city: "Hyderabad", state: "Telangana" },
    "500049": { lat: 17.6448, lng: 78.6811, city: "Hyderabad", state: "Telangana" },
    "500051": { lat: 17.6566, lng: 78.6897, city: "Hyderabad", state: "Telangana" },
    "500053": { lat: 17.6684, lng: 78.6983, city: "Hyderabad", state: "Telangana" },
    "500055": { lat: 17.6802, lng: 78.7069, city: "Hyderabad", state: "Telangana" },
    "500057": { lat: 17.6920, lng: 78.7155, city: "Hyderabad", state: "Telangana" },
    "500059": { lat: 17.7038, lng: 78.7241, city: "Hyderabad", state: "Telangana" },
    "500061": { lat: 17.7156, lng: 78.7327, city: "Hyderabad", state: "Telangana" },
    "500063": { lat: 17.7274, lng: 78.7413, city: "Hyderabad", state: "Telangana" },
    "500065": { lat: 17.7392, lng: 78.7499, city: "Hyderabad", state: "Telangana" },
    "500067": { lat: 17.7510, lng: 78.7585, city: "Hyderabad", state: "Telangana" },
    "500069": { lat: 17.7628, lng: 78.7671, city: "Hyderabad", state: "Telangana" },
    "500071": { lat: 17.7746, lng: 78.7757, city: "Hyderabad", state: "Telangana" },
    "500073": { lat: 17.7864, lng: 78.7843, city: "Hyderabad", state: "Telangana" },
    "500075": { lat: 17.7982, lng: 78.7929, city: "Hyderabad", state: "Telangana" },
    "500077": { lat: 17.8100, lng: 78.8015, city: "Hyderabad", state: "Telangana" },
    "500079": { lat: 17.8218, lng: 78.8101, city: "Hyderabad", state: "Telangana" },
    "500081": { lat: 17.8336, lng: 78.8187, city: "Hyderabad", state: "Telangana" },
    "500083": { lat: 17.8454, lng: 78.8273, city: "Hyderabad", state: "Telangana" },
    "500085": { lat: 17.8572, lng: 78.8359, city: "Hyderabad", state: "Telangana" },
    "500087": { lat: 17.8690, lng: 78.8445, city: "Hyderabad", state: "Telangana" },
    "500089": { lat: 17.8808, lng: 78.8531, city: "Hyderabad", state: "Telangana" },
    "500091": { lat: 17.8926, lng: 78.8617, city: "Hyderabad", state: "Telangana" },
    "500093": { lat: 17.9044, lng: 78.8703, city: "Hyderabad", state: "Telangana" },
    "500095": { lat: 17.9162, lng: 78.8789, city: "Hyderabad", state: "Telangana" },
    "500097": { lat: 17.9280, lng: 78.8875, city: "Hyderabad", state: "Telangana" },
    "500099": { lat: 17.9398, lng: 78.8961, city: "Hyderabad", state: "Telangana" },

    // Kolkata
    "700001": { lat: 22.5726, lng: 88.3639, city: "Kolkata", state: "West Bengal" },
    "700003": { lat: 22.5836, lng: 88.3723, city: "Kolkata", state: "West Bengal" },
    "700005": { lat: 22.5946, lng: 88.3807, city: "Kolkata", state: "West Bengal" },
    "700007": { lat: 22.6056, lng: 88.3891, city: "Kolkata", state: "West Bengal" },
    "700009": { lat: 22.6166, lng: 88.3975, city: "Kolkata", state: "West Bengal" },
    "700011": { lat: 22.6276, lng: 88.4059, city: "Kolkata", state: "West Bengal" },
    "700013": { lat: 22.6386, lng: 88.4143, city: "Kolkata", state: "West Bengal" },
    "700015": { lat: 22.6496, lng: 88.4227, city: "Kolkata", state: "West Bengal" },
    "700017": { lat: 22.6606, lng: 88.4311, city: "Kolkata", state: "West Bengal" },
    "700019": { lat: 22.6716, lng: 88.4395, city: "Kolkata", state: "West Bengal" },
    "700021": { lat: 22.6826, lng: 88.4479, city: "Kolkata", state: "West Bengal" },
    "700023": { lat: 22.6936, lng: 88.4563, city: "Kolkata", state: "West Bengal" },
    "700025": { lat: 22.7046, lng: 88.4647, city: "Kolkata", state: "West Bengal" },
    "700027": { lat: 22.7156, lng: 88.4731, city: "Kolkata", state: "West Bengal" },
    "700029": { lat: 22.7266, lng: 88.4815, city: "Kolkata", state: "West Bengal" },
    "700031": { lat: 22.7376, lng: 88.4899, city: "Kolkata", state: "West Bengal" },
    "700033": { lat: 22.7486, lng: 88.4983, city: "Kolkata", state: "West Bengal" },
    "700035": { lat: 22.7596, lng: 88.5067, city: "Kolkata", state: "West Bengal" },
    "700037": { lat: 22.7706, lng: 88.5151, city: "Kolkata", state: "West Bengal" },
    "700039": { lat: 22.7816, lng: 88.5235, city: "Kolkata", state: "West Bengal" },
    "700041": { lat: 22.7926, lng: 88.5319, city: "Kolkata", state: "West Bengal" },
    "700043": { lat: 22.8036, lng: 88.5403, city: "Kolkata", state: "West Bengal" },
    "700045": { lat: 22.8146, lng: 88.5487, city: "Kolkata", state: "West Bengal" },
    "700047": { lat: 22.8256, lng: 88.5571, city: "Kolkata", state: "West Bengal" },
    "700049": { lat: 22.8366, lng: 88.5655, city: "Kolkata", state: "West Bengal" },
    "700051": { lat: 22.8476, lng: 88.5739, city: "Kolkata", state: "West Bengal" },
    "700053": { lat: 22.8586, lng: 88.5823, city: "Kolkata", state: "West Bengal" },
    "700055": { lat: 22.8696, lng: 88.5907, city: "Kolkata", state: "West Bengal" },
    "700057": { lat: 22.8806, lng: 88.5991, city: "Kolkata", state: "West Bengal" },
    "700059": { lat: 22.8916, lng: 88.6075, city: "Kolkata", state: "West Bengal" },
    "700061": { lat: 22.9026, lng: 88.6159, city: "Kolkata", state: "West Bengal" },
    "700063": { lat: 22.9136, lng: 88.6243, city: "Kolkata", state: "West Bengal" },
    "700065": { lat: 22.9246, lng: 88.6327, city: "Kolkata", state: "West Bengal" },
    "700067": { lat: 22.9356, lng: 88.6411, city: "Kolkata", state: "West Bengal" },
    "700069": { lat: 22.9466, lng: 88.6495, city: "Kolkata", state: "West Bengal" },
    "700071": { lat: 22.9576, lng: 88.6579, city: "Kolkata", state: "West Bengal" },
    "700073": { lat: 22.9686, lng: 88.6663, city: "Kolkata", state: "West Bengal" },
    "700075": { lat: 22.9796, lng: 88.6747, city: "Kolkata", state: "West Bengal" },
    "700077": { lat: 22.9906, lng: 88.6831, city: "Kolkata", state: "West Bengal" },
    "700079": { lat: 23.0016, lng: 88.6915, city: "Kolkata", state: "West Bengal" },
    "700081": { lat: 23.0126, lng: 88.6999, city: "Kolkata", state: "West Bengal" },
    "700083": { lat: 23.0236, lng: 88.7083, city: "Kolkata", state: "West Bengal" },
    "700085": { lat: 23.0346, lng: 88.7167, city: "Kolkata", state: "West Bengal" },
    "700087": { lat: 23.0456, lng: 88.7251, city: "Kolkata", state: "West Bengal" },
    "700089": { lat: 23.0566, lng: 88.7335, city: "Kolkata", state: "West Bengal" },
    "700091": { lat: 23.0676, lng: 88.7419, city: "Kolkata", state: "West Bengal" },
    "700093": { lat: 23.0786, lng: 88.7503, city: "Kolkata", state: "West Bengal" },
    "700095": { lat: 23.0896, lng: 88.7587, city: "Kolkata", state: "West Bengal" },
    "700097": { lat: 23.1006, lng: 88.7671, city: "Kolkata", state: "West Bengal" },
    "700099": { lat: 23.1116, lng: 88.7755, city: "Kolkata", state: "West Bengal" },

    // Ahmedabad
    "380001": { lat: 23.0225, lng: 72.5714, city: "Ahmedabad", state: "Gujarat" },
    "380003": { lat: 23.0335, lng: 72.5600, city: "Ahmedabad", state: "Gujarat" },
    "380005": { lat: 23.0445, lng: 72.5486, city: "Ahmedabad", state: "Gujarat" },
    "380007": { lat: 23.0555, lng: 72.5372, city: "Ahmedabad", state: "Gujarat" },
    "380009": { lat: 23.0665, lng: 72.5258, city: "Ahmedabad", state: "Gujarat" },
    "380011": { lat: 23.0775, lng: 72.5144, city: "Ahmedabad", state: "Gujarat" },
    "380013": { lat: 23.0885, lng: 72.5030, city: "Ahmedabad", state: "Gujarat" },
    "380015": { lat: 23.0995, lng: 72.4916, city: "Ahmedabad", state: "Gujarat" },
    "380017": { lat: 23.1105, lng: 72.4802, city: "Ahmedabad", state: "Gujarat" },
    "380019": { lat: 23.1215, lng: 72.4688, city: "Ahmedabad", state: "Gujarat" },
    "380021": { lat: 23.1325, lng: 72.4574, city: "Ahmedabad", state: "Gujarat" },
    "380023": { lat: 23.1435, lng: 72.4460, city: "Ahmedabad", state: "Gujarat" },
    "380025": { lat: 23.1545, lng: 72.4346, city: "Ahmedabad", state: "Gujarat" },
    "380027": { lat: 23.1655, lng: 72.4232, city: "Ahmedabad", state: "Gujarat" },
    "380029": { lat: 23.1765, lng: 72.4118, city: "Ahmedabad", state: "Gujarat" },

    // Jaipur
    "302001": { lat: 26.9124, lng: 75.7873, city: "Jaipur", state: "Rajasthan" },
    "302002": { lat: 26.9234, lng: 75.7759, city: "Jaipur", state: "Rajasthan" },
    "302003": { lat: 26.9344, lng: 75.7645, city: "Jaipur", state: "Rajasthan" },
    "302004": { lat: 26.9454, lng: 75.7531, city: "Jaipur", state: "Rajasthan" },
    "302005": { lat: 26.9564, lng: 75.7417, city: "Jaipur", state: "Rajasthan" },
    "302006": { lat: 26.9674, lng: 75.7303, city: "Jaipur", state: "Rajasthan" },
    "302007": { lat: 26.9784, lng: 75.7189, city: "Jaipur", state: "Rajasthan" },
    "302008": { lat: 26.9894, lng: 75.7075, city: "Jaipur", state: "Rajasthan" },
    "302009": { lat: 27.0004, lng: 75.6961, city: "Jaipur", state: "Rajasthan" },
    "302010": { lat: 27.0114, lng: 75.6847, city: "Jaipur", state: "Rajasthan" },
    "302011": { lat: 27.0224, lng: 75.6733, city: "Jaipur", state: "Rajasthan" },
    "302012": { lat: 27.0334, lng: 75.6619, city: "Jaipur", state: "Rajasthan" },
    "302013": { lat: 27.0444, lng: 75.6505, city: "Jaipur", state: "Rajasthan" },
    "302014": { lat: 27.0554, lng: 75.6391, city: "Jaipur", state: "Rajasthan" },
    "302015": { lat: 27.0664, lng: 75.6277, city: "Jaipur", state: "Rajasthan" },
    "302016": { lat: 27.0774, lng: 75.6163, city: "Jaipur", state: "Rajasthan" },
    "302017": { lat: 27.0884, lng: 75.6049, city: "Jaipur", state: "Rajasthan" },
    "302018": { lat: 27.0994, lng: 75.5935, city: "Jaipur", state: "Rajasthan" },
    "302019": { lat: 27.1104, lng: 75.5821, city: "Jaipur", state: "Rajasthan" },
    "302020": { lat: 27.1214, lng: 75.5707, city: "Jaipur", state: "Rajasthan" },

    // Surat
    "395001": { lat: 21.1702, lng: 72.8311, city: "Surat", state: "Gujarat" },
    "395003": { lat: 21.1812, lng: 72.8197, city: "Surat", state: "Gujarat" },
    "395005": { lat: 21.1922, lng: 72.8083, city: "Surat", state: "Gujarat" },
    "395007": { lat: 21.2032, lng: 72.7969, city: "Surat", state: "Gujarat" },

    // Lucknow
    "226001": { lat: 26.8467, lng: 80.9462, city: "Lucknow", state: "Uttar Pradesh" },
    "226003": { lat: 26.8577, lng: 80.9348, city: "Lucknow", state: "Uttar Pradesh" },
    "226005": { lat: 26.8687, lng: 80.9234, city: "Lucknow", state: "Uttar Pradesh" },
    "226007": { lat: 26.8797, lng: 80.9120, city: "Lucknow", state: "Uttar Pradesh" },
    "226009": { lat: 26.8907, lng: 80.9006, city: "Lucknow", state: "Uttar Pradesh" },
    "226011": { lat: 26.9017, lng: 80.8892, city: "Lucknow", state: "Uttar Pradesh" },
    "226013": { lat: 26.9127, lng: 80.8778, city: "Lucknow", state: "Uttar Pradesh" },
    "226015": { lat: 26.9237, lng: 80.8664, city: "Lucknow", state: "Uttar Pradesh" },
    "226017": { lat: 26.9347, lng: 80.8550, city: "Lucknow", state: "Uttar Pradesh" },
    "226019": { lat: 26.9457, lng: 80.8436, city: "Lucknow", state: "Uttar Pradesh" },

    // Chandigarh
    "160001": { lat: 30.7333, lng: 76.7794, city: "Chandigarh", state: "Chandigarh" },
    "160003": { lat: 30.7443, lng: 76.7680, city: "Chandigarh", state: "Chandigarh" },
    "160005": { lat: 30.7553, lng: 76.7566, city: "Chandigarh", state: "Chandigarh" },
    "160007": { lat: 30.7663, lng: 76.7452, city: "Chandigarh", state: "Chandigarh" },
    "160009": { lat: 30.7773, lng: 76.7338, city: "Chandigarh", state: "Chandigarh" },
    "160011": { lat: 30.7883, lng: 76.7224, city: "Chandigarh", state: "Chandigarh" },
    "160013": { lat: 30.7993, lng: 76.7110, city: "Chandigarh", state: "Chandigarh" },
    "160015": { lat: 30.8103, lng: 76.6996, city: "Chandigarh", state: "Chandigarh" },
    "160017": { lat: 30.8213, lng: 76.6882, city: "Chandigarh", state: "Chandigarh" },
    "160019": { lat: 30.8323, lng: 76.6768, city: "Chandigarh", state: "Chandigarh" },

    // Indore
    "452001": { lat: 22.7196, lng: 75.8577, city: "Indore", state: "Madhya Pradesh" },
    "452003": { lat: 22.7306, lng: 75.8463, city: "Indore", state: "Madhya Pradesh" },
    "452005": { lat: 22.7416, lng: 75.8349, city: "Indore", state: "Madhya Pradesh" },
    "452007": { lat: 22.7526, lng: 75.8235, city: "Indore", state: "Madhya Pradesh" },
    "452009": { lat: 22.7636, lng: 75.8121, city: "Indore", state: "Madhya Pradesh" },
    "452011": { lat: 22.7746, lng: 75.8007, city: "Indore", state: "Madhya Pradesh" },
    "452013": { lat: 22.7856, lng: 75.7893, city: "Indore", state: "Madhya Pradesh" },
    "452015": { lat: 22.7966, lng: 75.7779, city: "Indore", state: "Madhya Pradesh" },
    "452017": { lat: 22.8076, lng: 75.7665, city: "Indore", state: "Madhya Pradesh" },
    "452019": { lat: 22.8186, lng: 75.7551, city: "Indore", state: "Madhya Pradesh" },

    // Bhopal
    "462001": { lat: 23.2599, lng: 77.4126, city: "Bhopal", state: "Madhya Pradesh" },
    "462003": { lat: 23.2709, lng: 77.4012, city: "Bhopal", state: "Madhya Pradesh" },
    "462005": { lat: 23.2819, lng: 77.3898, city: "Bhopal", state: "Madhya Pradesh" },
    "462007": { lat: 23.2929, lng: 77.3784, city: "Bhopal", state: "Madhya Pradesh" },
    "462009": { lat: 23.3039, lng: 77.3670, city: "Bhopal", state: "Madhya Pradesh" },
    "462011": { lat: 23.3149, lng: 77.3556, city: "Bhopal", state: "Madhya Pradesh" },
    "462013": { lat: 23.3259, lng: 77.3442, city: "Bhopal", state: "Madhya Pradesh" },
    "462015": { lat: 23.3369, lng: 77.3328, city: "Bhopal", state: "Madhya Pradesh" },
    "462017": { lat: 23.3479, lng: 77.3214, city: "Bhopal", state: "Madhya Pradesh" },
    "462019": { lat: 23.3589, lng: 77.3100, city: "Bhopal", state: "Madhya Pradesh" },

    // Patna
    "800001": { lat: 25.5941, lng: 85.1376, city: "Patna", state: "Bihar" },
    "800003": { lat: 25.6051, lng: 85.1262, city: "Patna", state: "Bihar" },
    "800005": { lat: 25.6161, lng: 85.1148, city: "Patna", state: "Bihar" },
    "800007": { lat: 25.6271, lng: 85.1034, city: "Patna", state: "Bihar" },
    "800009": { lat: 25.6381, lng: 85.0920, city: "Patna", state: "Bihar" },
    "800011": { lat: 25.6491, lng: 85.0806, city: "Patna", state: "Bihar" },
    "800013": { lat: 25.6601, lng: 85.0692, city: "Patna", state: "Bihar" },
    "800015": { lat: 25.6711, lng: 85.0578, city: "Patna", state: "Bihar" },
    "800017": { lat: 25.6821, lng: 85.0464, city: "Patna", state: "Bihar" },
    "800019": { lat: 25.6931, lng: 85.0350, city: "Patna", state: "Bihar" }
};

// Get PIN code details
function getPincodeDetails(pincode) {
    return indianPincodes[pincode] || null;
}

// Get all PIN codes as array
function getAllPincodes() {
    return Object.keys(indianPincodes).map(function(pincode) {
        return {
            pincode: pincode,
            city: indianPincodes[pincode].city,
            state: indianPincodes[pincode].state,
            lat: indianPincodes[pincode].lat,
            lng: indianPincodes[pincode].lng
        };
    });
}

// Search PIN codes by city or state
function searchPincodes(query) {
    query = query.toLowerCase();
    return Object.keys(indianPincodes).filter(function(pincode) {
        var data = indianPincodes[pincode];
        return data.city.toLowerCase().includes(query) ||
            data.state.toLowerCase().includes(query) ||
            pincode.includes(query);
    }).map(function(pincode) {
        return {
            pincode: pincode,
            city: indianPincodes[pincode].city,
            state: indianPincodes[pincode].state,
            lat: indianPincodes[pincode].lat,
            lng: indianPincodes[pincode].lng
        };
    });
}

// Initialize map with Indian PIN codes
function initPincodeMap(mapContainerId) {
    var mapContainer = document.getElementById(mapContainerId);
    if (!mapContainer) {
        console.error('Map container not found');
        return;
    }

    // Create a simple map visualization using markers
    var pincodes = getAllPincodes();
    var mapHTML = '<div class="pincode-map-container">';
    mapHTML += '<div class="map-header">';
    mapHTML += '<h3>Indian PIN Code Locations</h3>';
    mapHTML += '<span class="pincode-count">Total: ' + pincodes.length + ' locations</span>';
    mapHTML += '</div>';
    mapHTML += '<div class="map-scroll-container">';

    // Group by state
    var stateGroups = {};
    pincodes.forEach(function(pc) {
        if (!stateGroups[pc.state]) {
            stateGroups[pc.state] = [];
        }
        stateGroups[pc.state].push(pc);
    });

    // Create state sections
    Object.keys(stateGroups).forEach(function(state) {
        mapHTML += '<div class="state-group">';
        mapHTML += '<div class="state-header">' + state + ' (' + stateGroups[state].length + ' PIN codes)</div>';
        mapHTML += '<div class="pincode-list">';
        stateGroups[state].forEach(function(pc) {
            mapHTML += '<div class="pincode-marker" data-pincode="' + pc.pincode + '" data-city="' + pc.city + '" data-lat="' + pc.lat + '" data-lng="' + pc.lng + '">';
            mapHTML += '<span class="pincode-number">' + pc.pincode + '</span>';
            mapHTML += '<span class="pincode-city">' + pc.city + '</span>';
            mapHTML += '</div>';
        });
        mapHTML += '</div></div>';
    });

    mapHTML += '</div></div>';
    mapContainer.innerHTML = mapHTML;

    // Add click handlers
    var markers = mapContainer.querySelectorAll('.pincode-marker');
    markers.forEach(function(marker) {
        marker.addEventListener('click', function() {
            var pincode = this.getAttribute('data-pincode');
            var city = this.getAttribute('data-city');
            var lat = parseFloat(this.getAttribute('data-lat'));
            var lng = parseFloat(this.getAttribute('data-lng'));

            // Dispatch custom event for map click
            var event = new CustomEvent('pincodeSelected', {
                detail: { pincode: pincode, city: city, lat: lat, lng: lng }
            });
            document.dispatchEvent(event);
        });
    });

    return pincodes.length;
}

// Make functions globally available
window.indianPincodes = indianPincodes;
window.getPincodeDetails = getPincodeDetails;
window.getAllPincodes = getAllPincodes;
window.searchPincodes = searchPincodes;
window.initPincodeMap = initPincodeMap;