// Main JavaScript for BedBridge

// API Base URL - using port 5001 as confirmed by user
const API_BASE_URL = 'http://localhost:5001/api';

// Leaflet (OpenStreetMap) variables
var map = null;
var markers = [];

// Geocode pincode to coordinates - uses local database first, then OpenStreetMap Nominatim API as fallback
async function geocodePincode(pincode) {
    if (!pincode) {
        return null;
    }

    // First, try to get coordinates from local PIN code database
    if (typeof getPincodeDetails === 'function') {
        var localData = getPincodeDetails(pincode);
        if (localData) {
            console.log('Found PIN code in local database: ' + pincode);
            return {
                lat: localData.lat,
                lng: localData.lng
            };
        }
    }

    // If not found locally, try OpenStreetMap Nominatim API (free, no key required)
    try {
        var response = await fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(pincode + ', India'));
        var data = await response.json();
        if (data && data.length > 0) {
            return {
                lat: parseFloat(data[0].lat),
                lng: parseFloat(data[0].lon)
            };
        }
    } catch (error) {
        console.error('Geocoding failed for pincode: ' + pincode, error);
    }

    // Default to Delhi if geocoding fails
    return { lat: 28.6139, lng: 77.2090 };
}

// Initialize and display Leaflet (OpenStreetMap) with hospital markers
function initMap(hospitals, userLat, userLon) {
    var mapContainer = document.getElementById('map-container');
    var mapDiv = document.getElementById('map');

    if (!mapContainer || !mapDiv) {
        console.error('Map container not found');
        return;
    }

    // Check if Leaflet is loaded
    if (typeof L === 'undefined') {
        console.error('Leaflet library not loaded');
        mapContainer.style.display = 'none';
        return;
    }

    // Show the map container
    mapContainer.style.display = 'block';

    // If map already exists, remove it and recreate
    if (map) {
        map.remove();
        map = null;
    }

    // Create new map
    map = L.map(mapDiv).setView([userLat, userLon], 12);

    // Add OpenStreetMap tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19
    }).addTo(map);

    // Clear existing markers
    markers = [];

    // Add user marker (center) - blue circle
    var userIcon = L.divIcon({
        className: 'user-marker',
        html: '<div style="width:20px;height:20px;background:#4285F4;border:3px solid white;border-radius:50%;box-shadow:0 2px 5px rgba(0,0,0,0.3);"></div>',
        iconSize: [20, 20],
        iconAnchor: [10, 10]
    });
    var userMarker = L.marker([userLat, userLon], { icon: userIcon }).addTo(map);
    userMarker.bindPopup('<strong>Your Location</strong>');
    markers.push(userMarker);

    // Add hospital markers
    hospitals.forEach(function(hospital) {
        // Create custom icon based on bed availability
        var availableBeds = (hospital.icu_beds || 0) + (hospital.oxygen_beds || 0) + (hospital.ventilator_beds || 0);
        var iconColor = availableBeds > 0 ? '#28a745' : '#dc3545';

        var hospitalIcon = L.divIcon({
            className: 'hospital-marker',
            html: '<div style="width:30px;height:30px;background:' + iconColor + ';border:2px solid white;border-radius:5px;box-shadow:0 2px 5px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;color:white;font-weight:bold;font-size:12px;">H</div>',
            iconSize: [30, 30],
            iconAnchor: [15, 15]
        });

        var marker = L.marker([hospital.latitude, hospital.longitude], { icon: hospitalIcon }).addTo(map);

        // Info window content
        var infoContent = '<div style="padding: 5px; min-width: 150px;">' +
            '<strong style="font-size: 14px;">' + hospital.name + '</strong><br>' +
            '<span style="font-size: 12px; color: #666;">' + hospital.address + '</span><br>' +
            '<span style="font-size: 12px;">Distance: ' + (hospital.distance || 'N/A') + ' km</span><br>' +
            '<div style="font-size: 11px; margin-top: 5px;">' +
            '<span>ICU: ' + (hospital.icu_beds || 0) + '</span> | ' +
            '<span>O2: ' + (hospital.oxygen_beds || 0) + '</span> | ' +
            '<span>Vent: ' + (hospital.ventilator_beds || 0) + '</span>' +
            '</div>' +
            '</div>';

        marker.bindPopup(infoContent);
        markers.push(marker);
    });

    // Fit bounds to show all markers
    if (hospitals.length > 0 && markers.length > 0) {
        var group = new L.featureGroup(markers);
        map.fitBounds(group.getBounds().pad(0.1));
    }
}

// Clear all markers from the map
function clearMarkers() {
    markers.forEach(function(marker) {
        if (map && marker) {
            map.removeLayer(marker);
        }
    });
    markers = [];
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    loadLiveStats();
    loadNearbyHospitals();
    setupEventListeners();
    createParticles();
});

// App initialization
function initializeApp() {
    console.log('BedBridge initialized');
    checkEmergencyStatus();
    animateElements();
}

// Fetch hospitals from API
async function fetchHospitals() {
    try {
        const response = await fetch(API_BASE_URL + '/hospitals');
        if (!response.ok) {
            throw new Error('Failed to fetch hospitals');
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching hospitals:', error);
        return [];
    }
}

// Fetch nearby hospitals from API
async function fetchNearbyHospitals(lat, lon, radius) {
    try {
        const response = await fetch(API_BASE_URL + '/hospitals/nearby?lat=' + lat + '&lon=' + lon + '&radius=' + radius);
        if (!response.ok) {
            throw new Error('Failed to fetch nearby hospitals');
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching nearby hospitals:', error);
        return [];
    }
}

// Live stats update
function loadLiveStats() {
    // Fetch real-time data from API
    fetchHospitals().then(function(hospitals) {
        updateStatsFromAPI(hospitals);
    });

    // Also update every 30 seconds
    setInterval(function() {
        fetchHospitals().then(function(hospitals) {
            updateStatsFromAPI(hospitals);
        });
    }, 30000);
}

function updateStatsFromAPI(hospitals) {
    var icuCount = document.getElementById('icuCount');
    var ventCount = document.getElementById('ventCount');
    var oxygenCount = document.getElementById('oxygenCount');
    var hospitalCount = document.getElementById('hospitalCount');

    // Calculate totals from API data
    var totalICU = 0;
    var totalVent = 0;
    var totalOxygen = 0;

    hospitals.forEach(function(h) {
        totalICU += h.icu_beds || 0;
        totalVent += h.ventilator_beds || 0;
        totalOxygen += h.oxygen_beds || 0;
    });

    if (icuCount) animateNumber(icuCount, totalICU);
    if (ventCount) animateNumber(ventCount, totalVent);
    if (oxygenCount) animateNumber(oxygenCount, totalOxygen);
    if (hospitalCount) animateNumber(hospitalCount, hospitals.length);
}

// Animate number change
function animateNumber(element, newValue) {
    if (!element) return;

    var oldValue = parseInt(element.innerText.replace(/,/g, '')) || 0;
    var duration = 1000;
    var steps = 60;
    var stepValue = (newValue - oldValue) / steps;
    var currentStep = 0;

    var interval = setInterval(function() {
        currentStep++;
        var currentValue = Math.floor(oldValue + (stepValue * currentStep));
        element.innerText = currentValue.toLocaleString();

        if (currentStep >= steps) {
            clearInterval(interval);
            element.innerText = newValue.toLocaleString();
        }
    }, duration / steps);
}

// Load nearby hospitals
function loadNearbyHospitals() {
    var container = document.getElementById('nearbyHospitals');
    if (!container) return;

    // Try to get user's location
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            function(position) {
                var lat = position.coords.latitude;
                var lon = position.coords.longitude;
                loadNearbyHospitalsFromAPI(lat, lon, container);
            },
            function(error) {
                // If location not available, load all hospitals
                loadAllHospitals(container);
            }
        );
    } else {
        loadAllHospitals(container);
    }
}

async function loadNearbyHospitalsFromAPI(lat, lon, container) {
    try {
        var hospitals = await fetchNearbyHospitals(lat, lon, 10);
        displayNearbyHospitals(hospitals, container);
    } catch (error) {
        console.error('Error loading nearby hospitals:', error);
        container.innerHTML = '<p class="loading">Unable to load hospitals. Please try again.</p>';
    }
}

async function loadAllHospitals(container) {
    try {
        var hospitals = await fetchHospitals();
        displayNearbyHospitals(hospitals.slice(0, 5), container);
    } catch (error) {
        console.error('Error loading hospitals:', error);
        container.innerHTML = '<p class="loading">Unable to load hospitals. Please try again.</p>';
    }
}

function displayNearbyHospitals(hospitals, container) {
    if (!hospitals || hospitals.length === 0) {
        container.innerHTML = '<p class="no-results">No hospitals found nearby.</p>';
        return;
    }

    container.innerHTML = hospitals.map(function(h) {
        var distance = h.distance ? h.distance + ' km' : '';
        return '<div class="hospital-item glass">' +
            '<div class="hospital-info">' +
            '<h4>' + h.name + '</h4>' +
            '<span class="distance"><i class="fas fa-location-dot"></i> ' + distance + '</span>' +
            '</div>' +
            '<div class="hospital-beds">' +
            '<span class="bed-badge ' + (h.icu_beds > 0 ? 'available' : 'full') + '">' +
            '<i class="fas fa-heartbeat"></i> ICU: ' + (h.icu_beds || 0) +
            '</span>' +
            '<span class="bed-badge ' + (h.oxygen_beds > 0 ? 'available' : 'full') + '">' +
            '<i class="fas fa-wind"></i> O2: ' + (h.oxygen_beds || 0) +
            '</span>' +
            '</div>' +
            '<div class="hospital-actions">' +
            '<button class="action-btn" onclick="callHospital(\'' + (h.phone || '') + '\')">' +
            '<i class="fas fa-phone"></i>' +
            '</button>' +
            '<button class="action-btn" onclick="navigateTo(\'' + h.name + ' ' + h.address + '\')">' +
            '<i class="fas fa-directions"></i>' +
            '</button>' +
            '</div>' +
            '</div>';
    }).join('');
}

// Check if input looks like a pincode (5-6 digits)
function isPincode(input) {
    return /^\d{5,6}$/.test(input.trim());
}

// Search hospitals
async function searchHospitals(location, bedType, radiusKm) {
    var results = document.getElementById('search-results');
    if (results) {
        results.innerHTML = '<div class="loading"><div class="spinner"></div><p>Searching hospitals...</p></div>';
    }

    try {
        // Default coordinates (Delhi, India)
        var lat = 28.6139;
        var lon = 77.2090;
        var useGeocoding = false;

        // Check if input looks like a pincode
        if (location && isPincode(location)) {
            // Try to geocode the pincode
            var coordinates = await geocodePincode(location);
            if (coordinates) {
                lat = coordinates.lat;
                lon = coordinates.lng;
                useGeocoding = true;
                console.log('Geocoded pincode to: ' + lat + ', ' + lon);
            }
        } else if (navigator.geolocation && !useGeocoding) {
            // Try to get user's location
            try {
                var position = await new Promise(function(resolve, reject) {
                    navigator.geolocation.getCurrentPosition(resolve, reject);
                });
                lat = position.coords.latitude;
                lon = position.coords.longitude;
            } catch (e) {
                console.log('Using default location');
            }
        }

        var selectedRadius = parseFloat(radiusKm);
        if (!selectedRadius || selectedRadius <= 0) {
            selectedRadius = 50;
        }

        var hospitals = await fetchNearbyHospitals(lat, lon, selectedRadius);
        var selectedBedType = bedType || 'all';

        if (selectedBedType !== 'all') {
            var bedTypeFieldMap = {
                icu: 'icu_beds',
                oxygen: 'oxygen_beds',
                ventilator: 'ventilator_beds',
                general: 'general_beds'
            };
            var bedField = bedTypeFieldMap[selectedBedType];
            if (bedField) {
                hospitals = hospitals.filter(function(hospital) {
                    return (hospital[bedField] || 0) > 0;
                });
            }
        }

        displaySearchResults(hospitals);

        // Initialize map with results if Leaflet is loaded
        if (hospitals.length > 0) {
            initMap(hospitals, lat, lon);
        }
    } catch (error) {
        console.error('Error searching hospitals:', error);
        if (results) {
            results.innerHTML = '<div class="no-results"><h3>Error</h3><p>Unable to search hospitals. Please try again.</p></div>';
        }
    }
}

// Display search results
function displaySearchResults(hospitals) {
    var results = document.getElementById('search-results');
    if (!results) return;

    if (!hospitals || hospitals.length === 0) {
        results.innerHTML = '<div class="no-results"><h3>No Results</h3><p>No hospitals found in your area.</p></div>';
        return;
    }

    results.innerHTML = hospitals.map(function(hospital) {
        var distance = hospital.distance ? hospital.distance + ' km' : '';
        var lastUpdate = hospital.last_update ? new Date(hospital.last_update).toLocaleString() : 'N/A';

        return '<div class="hospital-card glass animate-scale">' +
            '<div class="hospital-header">' +
            '<h3>' + hospital.name + '</h3>' +
            '<span class="distance">' + distance + '</span>' +
            '</div>' +
            '<div class="bed-stats">' +
            '<div class="bed-type ' + (hospital.icu_beds > 0 ? 'available' : 'full') + '">' +
            '<span class="bed-label">ICU</span>' +
            '<span class="bed-count">' + (hospital.icu_beds || 0) + '</span>' +
            '</div>' +
            '<div class="bed-type ' + (hospital.oxygen_beds > 0 ? 'available' : 'full') + '">' +
            '<span class="bed-label">Oxygen</span>' +
            '<span class="bed-count">' + (hospital.oxygen_beds || 0) + '</span>' +
            '</div>' +
            '<div class="bed-type ' + (hospital.ventilator_beds > 0 ? 'available' : 'full') + '">' +
            '<span class="bed-label">Ventilator</span>' +
            '<span class="bed-count">' + (hospital.ventilator_beds || 0) + '</span>' +
            '</div>' +
            '<div class="bed-type ' + (hospital.general_beds > 0 ? 'available' : 'full') + '">' +
            '<span class="bed-label">General</span>' +
            '<span class="bed-count">' + (hospital.general_beds || 0) + '</span>' +
            '</div>' +
            '</div>' +
            '<div class="hospital-footer">' +
            '<span class="last-update">Updated: ' + lastUpdate + '</span>' +
            '<div class="hospital-actions">' +
            '<button class="call-btn" onclick="callHospital(\'' + (hospital.phone || '') + '\')">Call</button>' +
            '<button class="nav-btn" onclick="navigateTo(\'' + hospital.name + ' ' + hospital.address + '\')">Navigate</button>' +
            '</div>' +
            '</div>' +
            '</div>';
    }).join('');
}

// Call hospital
function callHospital(phone) {
    if (phone) {
        window.location.href = 'tel:' + phone;
    } else {
        alert('Phone number not available');
    }
}

// Navigate to hospital
function navigateTo(destination) {
    window.open('https://maps.google.com/?q=' + encodeURIComponent(destination), '_blank');
}

// Check emergency status
function checkEmergencyStatus() {
    var emergencyMode = localStorage.getItem('emergencyMode');
    if (emergencyMode === 'active') {
        document.body.classList.add('emergency-active');
        showEmergencyNotification();
    }
}

// Show emergency notification
function showEmergencyNotification() {
    var notification = document.createElement('div');
    notification.className = 'emergency-notification glass animate-slide-down';
    notification.innerHTML = '<div class="notification-content">' +
        '<span class="notification-icon">!</span>' +
        '<div class="notification-text">' +
        '<h4>Emergency Mode Active</h4>' +
        '<p>Your location is being tracked for nearest hospital</p>' +
        '</div>' +
        '<button class="notification-close" onclick="this.parentElement.parentElement.remove()">x</button>' +
        '</div>';
    document.body.appendChild(notification);

    setTimeout(function() {
        notification.remove();
    }, 5000);
}

// Create floating particles
function createParticles() {
    var particleCount = 50;

    for (var i = 0; i < particleCount; i++) {
        var particle = document.createElement('div');
        particle.className = 'particle';

        var size = Math.random() * 10 + 5;
        var posX = Math.random() * window.innerWidth;
        var delay = Math.random() * 5;
        var duration = Math.random() * 10 + 10;

        particle.style.width = size + 'px';
        particle.style.height = size + 'px';
        particle.style.left = posX + 'px';
        particle.style.animation = 'float-particle ' + duration + 's linear ' + delay + 's infinite';

        document.body.appendChild(particle);
    }
}

// Setup event listeners
function setupEventListeners() {
    // Search functionality
    var searchInput = document.getElementById('locationSearch') || document.getElementById('location-search');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }

    // Emergency button
    var emergencyBtn = document.querySelector('.emergency-btn');
    if (emergencyBtn) {
        emergencyBtn.addEventListener('click', activateEmergencyMode);
    }

    // Smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            var target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Activate emergency mode
function activateEmergencyMode(e) {
    if (e) e.preventDefault();
    localStorage.setItem('emergencyMode', 'active');
    window.location.href = 'emergency.html';
}

// Animate elements on scroll
function animateElements() {
    var observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in');
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.feature-card, .stat-card').forEach(function(el) {
        observer.observe(el);
    });
}

// Make functions globally available
window.searchHospitals = searchHospitals;
window.filterBeds = filterBeds;
window.callHospital = callHospital;
window.navigateTo = navigateTo;
window.loadMap = loadMap;
window.geocodePincode = geocodePincode;
window.initMap = initMap;
window.performSearch = performSearch;
window.activateEmergencyMode = activateEmergencyMode;
window.initPincodeMap = initPincodeMap;

function filterBeds(type) {
    window.location.href = 'search.html?bedType=' + type;
}

function loadMap() {
    var mapPreview = document.getElementById('mapPreview');
    if (mapPreview) {
        mapPreview.innerHTML = '<div class="loading">Loading map...</div>';
        setTimeout(function() {
            mapPreview.innerHTML = '<iframe src="https://www.openstreetmap.org/export/embed.html?bbox=76.8,28.4,77.4,28.8&layer=mapnik" width="100%" height="100%" style="border:0;"></iframe>';
        }, 1000);
    }
}

// performSearch function - called from search.html
function performSearch() {
    var locationInput = document.getElementById('location-search');
    var bedType = document.getElementById('bed-type') ? document.getElementById('bed-type').value : 'all';
    var distance = document.getElementById('distance') ? document.getElementById('distance').value : '10';
    var location = locationInput ? locationInput.value.trim() : '';

    if (typeof searchHospitals === 'function') {
        searchHospitals(location, bedType, distance);
    } else {
        console.error('searchHospitals function not found');
    }
}

function initPincodeMap() {
    var mapContainer = document.getElementById('pincode-map');
    if (!mapContainer) {
        console.log('Pincode map container not found');
        return;
    }

    // Check if Leaflet is loaded
    if (typeof L === 'undefined') {
        mapContainer.innerHTML = '<p style="text-align:center; padding:20px;">Map library not loaded. Please refresh the page.</p>';
        return;
    }

    // Display a message that map functionality requires location input
    mapContainer.innerHTML = '<p style="text-align:center; padding:20px;">Enter a PIN code in the search box to find hospitals.</p>';
}