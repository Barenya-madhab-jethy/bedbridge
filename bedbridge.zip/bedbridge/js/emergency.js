// Emergency Mode JavaScript

// API Base URL
const API_BASE_URL = 'http://localhost:5001/api';

document.addEventListener('DOMContentLoaded', function() {
    initializeEmergencyMode();
    detectLocation();
    startEmergencyCountdown();
});

function initializeEmergencyMode() {
    document.body.classList.add('emergency-active');
    playEmergencySound();
    showEmergencyNotification();
}

function playEmergencySound() {
    console.log('Playing emergency alert');
}

function detectLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            function(position) {
                var latitude = position.coords.latitude;
                var longitude = position.coords.longitude;
                console.log('Location detected:', latitude, longitude);
                updateLocationStatus(latitude, longitude);
                findNearbyHospitals(latitude, longitude);
            },
            function(error) {
                console.error('Location error:', error);
                handleLocationError(error);
            }, {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );
    } else {
        handleLocationError({ message: 'Geolocation not supported' });
    }
}

function updateLocationStatus(lat, lon) {
    var statusEl = document.querySelector('.status-text h3');
    if (statusEl) {
        statusEl.innerHTML = 'Location detected!<br><small>Finding nearest hospitals...</small>';
    }
}

async function findNearbyHospitals(lat, lon) {
    try {
        var response = await fetch(API_BASE_URL + '/hospitals/nearby?lat=' + lat + '&lon=' + lon + '&radius=5');
        if (!response.ok) {
            throw new Error('Failed to fetch nearby hospitals');
        }
        var hospitals = await response.json();

        if (hospitals && hospitals.length > 0) {
            displayNearestHospital(hospitals[0]);
        } else {
            showNoHospitalsFound();
        }
    } catch (error) {
        console.error('Error finding nearby hospitals:', error);
        // Show mock data as fallback
        var mockHospital = {
            name: 'City General Hospital',
            distance: '1.2 km',
            eta: '4 minutes',
            icu_beds: 3,
            phone: '+1 234 567 8900'
        };
        displayNearestHospital(mockHospital);
    }
}

function displayNearestHospital(hospital) {
    var container = document.getElementById('nearest-hospital');
    if (!container) return;

    container.innerHTML = '<div class="hospital-info">' +
        '<div class="hospital-name">' +
        '<span class="name">' + hospital.name + '</span>' +
        '<span class="distance-badge">' + (hospital.distance ? hospital.distance + ' km' : '') + '</span>' +
        '</div>' +
        '<div class="hospital-details">' +
        '<div class="detail">' +
        '<span class="detail-label">ETA:</span>' +
        '<span class="detail-value highlight">' + (hospital.eta || 'N/A') + '</span>' +
        '</div>' +
        '<div class="detail">' +
        '<span class="detail-label">ICU Available:</span>' +
        '<span class="detail-value available">' + (hospital.icu_beds || 0) + ' beds</span>' +
        '</div>' +
        '<div class="detail">' +
        '<span class="detail-label">Contact:</span>' +
        '<span class="detail-value">' + (hospital.phone || 'N/A') + '</span>' +
        '</div>' +
        '</div>' +
        '</div>';

    // Update call button with actual phone number
    var callBtn = document.querySelector('.emergency-call-btn');
    if (callBtn && hospital.phone) {
        callBtn.onclick = function() {
            callEmergency(hospital.phone);
        };
    }

    // Update navigate button with actual hospital name
    var navBtn = document.querySelector('.emergency-nav-btn');
    if (navBtn && hospital.name) {
        navBtn.onclick = function() {
            navigateEmergency(hospital.name, hospital.address);
        };
    }
}

function showNoHospitalsFound() {
    var container = document.getElementById('nearest-hospital');
    if (!container) return;

    container.innerHTML = '<div class="hospital-info">' +
        '<div class="hospital-name">' +
        '<span class="name">No Hospitals Found</span>' +
        '</div>' +
        '<div class="hospital-details">' +
        '<p style="text-align:center; color: rgba(255,255,255,0.6);">No hospitals with available beds found within 5km. Try expanding your search radius.</p>' +
        '</div>' +
        '</div>';
}

function callEmergency(phoneNumber) {
    if (phoneNumber) {
        window.location.href = 'tel:' + phoneNumber;
    } else {
        alert('Phone number not available');
    }
}

function navigateEmergency(hospitalName, address) {
    var destination = address || hospitalName;
    window.open('https://maps.google.com/?q=' + encodeURIComponent(destination), '_blank');
}

function cancelEmergency() {
    if (confirm('Are you sure you want to cancel emergency mode?')) {
        localStorage.removeItem('emergencyMode');
        window.location.href = 'index.html';
    }
}

function startEmergencyCountdown() {
    var timeLeft = 180; // 3 minutes in seconds

    var timer = setInterval(function() {
        timeLeft--;

        var minutes = Math.floor(timeLeft / 60);
        var seconds = timeLeft % 60;

        var timerDisplay = document.querySelector('.progress-bar p');
        if (timerDisplay) {
            timerDisplay.textContent = 'Auto-refresh in ' + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
        }

        if (timeLeft <= 0) {
            clearInterval(timer);
            refreshEmergencyData();
        }
    }, 1000);
}

function refreshEmergencyData() {
    console.log('Refreshing emergency data');
    detectLocation();
    startEmergencyCountdown();
}

function handleLocationError(error) {
    var statusEl = document.querySelector('.status-text');
    if (statusEl) {
        statusEl.innerHTML = '<h3 style="color: #ff6b6b;">Location Error</h3>' +
            '<p>Please enable location services or enter your location manually</p>' +
            '<button onclick="manualLocationInput()" class="manual-location-btn">Enter Location Manually</button>';
    }
}

function manualLocationInput() {
    var location = prompt('Enter your location or pincode:');
    if (location) {
        console.log('Manual location:', location);
        // For now, use default coordinates if manual input
        findNearbyHospitals(40.7128, -74.0060);
    }
}

// Make functions globally available
window.callEmergency = callEmergency;
window.navigateEmergency = navigateEmergency;
window.cancelEmergency = cancelEmergency;
window.manualLocationInput = manualLocationInput;