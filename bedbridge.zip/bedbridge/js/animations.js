// BedBridge - Advanced Animations Library

// Initialize all animations when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initScrollAnimations();
    initHoverAnimations();
    initPageTransitions();
    initParallaxEffects();
    initTypewriterEffect();
    initCounterAnimations();
    initMagneticButtons();
    initTiltEffect();
    initGlitchEffect();
});

// 1. Scroll-Based Animations
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('in-view');

                // Add random delay for staggered effect
                const delay = entry.target.dataset.delay || 0;
                entry.target.style.transitionDelay = `${delay}s`;

                // Trigger child animations
                animateChildren(entry.target);
            }
        });
    }, observerOptions);

    // Observe elements with animation classes
    document.querySelectorAll(
        '.animate-on-scroll, .feature-card, .stat-card, .hospital-card, .glass'
    ).forEach(el => observer.observe(el));
}

function animateChildren(parent) {
    const children = parent.children;
    Array.from(children).forEach((child, index) => {
        if (child.classList.contains('animate-child')) {
            child.style.animation = `fadeInUp 0.6s ease ${index * 0.1}s forwards`;
        }
    });
}

// 2. Hover Animations
function initHoverAnimations() {
    // 3D Tilt effect for cards
    document.querySelectorAll('.tilt-effect, .feature-card, .hospital-card').forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = (y - centerY) / 20;
            const rotateY = (centerX - x) / 20;

            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
        });
    });

    // Ripple effect for buttons
    document.querySelectorAll('.primary-btn, .secondary-btn, .emergency-btn').forEach(btn => {
        btn.addEventListener('click', createRipple);
    });
}

function createRipple(e) {
    const button = e.currentTarget;
    const ripple = document.createElement('span');
    const rect = button.getBoundingClientRect();

    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;

    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;
    ripple.classList.add('ripple');

    button.appendChild(ripple);

    setTimeout(() => ripple.remove(), 600);
}

// 3. Page Transitions
function initPageTransitions() {
    // Smooth page transitions
    document.querySelectorAll('a').forEach(link => {
        // Skip external links
        if (link.hostname !== window.location.hostname && link.hostname !== '') return;

        link.addEventListener('click', (e) => {
            if (link.target === '_blank') return;

            e.preventDefault();
            const href = link.getAttribute('href');

            if (href && !href.startsWith('#')) {
                transitionToPage(href);
            }
        });
    });
}

function transitionToPage(url) {
    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'page-transition-overlay';
    document.body.appendChild(overlay);

    // Animate overlay
    setTimeout(() => {
        overlay.style.transform = 'scaleY(1)';
    }, 10);

    // Navigate after animation
    setTimeout(() => {
        window.location.href = url;
    }, 500);
}

// 4. Parallax Effects
function initParallaxEffects() {
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;

        document.querySelectorAll('.parallax').forEach(el => {
            const speed = el.dataset.speed || 0.5;
            el.style.transform = `translateY(${scrolled * speed}px)`;
        });

        // Parallax for gradient spheres
        document.querySelectorAll('.gradient-sphere, .gradient-sphere-2').forEach(el => {
            el.style.transform = `translate(${scrolled * 0.02}px, ${scrolled * 0.01}px)`;
        });
    });
}

// 5. Typewriter Effect
function initTypewriterEffect() {
    const elements = document.querySelectorAll('.typewriter');

    elements.forEach(el => {
        const text = el.textContent;
        el.textContent = '';
        el.style.visibility = 'visible';

        let i = 0;
        const type = () => {
            if (i < text.length) {
                el.textContent += text.charAt(i);
                i++;
                setTimeout(type, 100);
            }
        };

        // Start typing when element is in view
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    type();
                    observer.unobserve(entry.target);
                }
            });
        });

        observer.observe(el);
    });
}

// 6. Counter Animations
function initCounterAnimations() {
    const counters = document.querySelectorAll('.counter');

    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = parseInt(counter.getAttribute('data-duration')) || 2000;
        const step = target / (duration / 16); // 60fps

        let current = 0;

        const updateCounter = () => {
            current += step;
            if (current < target) {
                counter.textContent = Math.floor(current).toLocaleString();
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target.toLocaleString();
            }
        };

        // Start counting when element is in view
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    updateCounter();
                    observer.unobserve(entry.target);
                }
            });
        });

        observer.observe(counter);
    });
}

// 7. Magnetic Buttons
function initMagneticButtons() {
    document.querySelectorAll('.magnetic-btn, .primary-btn, .emergency-btn').forEach(btn => {
        btn.addEventListener('mousemove', (e) => {
            const rect = btn.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;

            btn.style.transform = `translate(${x * 0.3}px, ${y * 0.3}px)`;
        });

        btn.addEventListener('mouseleave', () => {
            btn.style.transform = 'translate(0, 0)';
        });
    });
}

// 8. Tilt Effect
function initTiltEffect() {
    document.querySelectorAll('.tilt-card').forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = (e.clientX - rect.left) / rect.width - 0.5;
            const y = (e.clientY - rect.top) / rect.height - 0.5;

            card.style.transform = `
                perspective(1000px)
                rotateX(${y * 10}deg)
                rotateY(${x * 10}deg)
                translateZ(20px)
            `;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateZ(0)';
        });
    });
}

// 9. Glitch Effect
function initGlitchEffect() {
    document.querySelectorAll('.glitch').forEach(el => {
        const text = el.textContent;

        setInterval(() => {
            if (Math.random() < 0.1) { // 10% chance
                el.style.transform = `skew(${Math.random() * 10 - 5}deg)`;
                el.style.textShadow = `
                    ${Math.random() * 10 - 5}px ${Math.random() * 10 - 5}px 0 rgba(255,0,0,0.5),
                    ${Math.random() * 10 - 5}px ${Math.random() * 10 - 5}px 0 rgba(0,255,0,0.5)
                `;

                setTimeout(() => {
                    el.style.transform = '';
                    el.style.textShadow = '';
                }, 50);
            }
        }, 3000);
    });
}

// 10. Particle System
class ParticleSystem {
    constructor(container, count = 50) {
        this.container = container;
        this.count = count;
        this.particles = [];
        this.init();
    }

    init() {
        for (let i = 0; i < this.count; i++) {
            this.createParticle();
        }
        this.animate();
    }

    createParticle() {
        const particle = document.createElement('div');
        particle.className = 'dynamic-particle';

        const size = Math.random() * 6 + 2;
        const posX = Math.random() * 100;
        const delay = Math.random() * 5;
        const duration = Math.random() * 10 + 10;

        particle.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            background: rgba(255, 255, 255, ${Math.random() * 0.3 + 0.1});
            border-radius: 50%;
            left: ${posX}%;
            top: -10%;
            animation: float-particle ${duration}s linear ${delay}s infinite;
            pointer-events: none;
        `;

        this.container.appendChild(particle);
        this.particles.push(particle);
    }

    animate() {
        // Additional animation logic if needed
    }
}

// 11. Text Splitting Animation
function splitTextForAnimation() {
    document.querySelectorAll('.split-text').forEach(el => {
        const text = el.textContent;
        const chars = text.split('');

        el.innerHTML = chars.map((char, i) =>
            `<span class="char" style="animation-delay: ${i * 0.03}s">${char}</span>`
        ).join('');
    });
}

// 12. Progress Bar Animation
function animateProgressBars() {
    document.querySelectorAll('.progress-bar').forEach(bar => {
        const targetWidth = bar.getAttribute('data-width') || '0%';

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    bar.style.width = targetWidth;
                    observer.unobserve(entry.target);
                }
            });
        });

        observer.observe(bar);
    });
}

// 13. Floating Animation with Random Delay
function randomizeFloatAnimations() {
    document.querySelectorAll('.float-animation').forEach(el => {
        const delay = Math.random() * 2;
        const duration = Math.random() * 2 + 3;
        const distance = Math.random() * 20 + 10;

        el.style.animation = `float-${el.id || 'custom'} ${duration}s ease-in-out ${delay}s infinite`;

        // Create custom keyframe
        const style = document.createElement('style');
        style.textContent = `
            @keyframes float-${el.id || 'custom'} {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-${distance}px); }
            }
        `;
        document.head.appendChild(style);
    });
}

// 14. Gradient Shift Animation
function gradientShift() {
    let hue = 0;

    setInterval(() => {
        hue = (hue + 1) % 360;

        document.querySelectorAll('.gradient-shift').forEach(el => {
            el.style.background = `linear-gradient(${hue}deg, #ff3366, #00d4ff, #7c3aed)`;
        });
    }, 100);
}

// 15. Mouse Trail Effect
function initMouseTrail() {
    const trail = [];
    const trailLength = 20;

    for (let i = 0; i < trailLength; i++) {
        const dot = document.createElement('div');
        dot.className = 'mouse-trail';
        dot.style.cssText = `
            position: fixed;
            width: 8px;
            height: 8px;
            background: rgba(255, 51, 102, ${1 - i / trailLength});
            border-radius: 50%;
            pointer-events: none;
            z-index: 9999;
            transition: all 0.1s ease;
            filter: blur(${i * 0.5}px);
        `;
        document.body.appendChild(dot);
        trail.push(dot);
    }

    let mouseX = 0,
        mouseY = 0;

    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });

    function updateTrail() {
        for (let i = trail.length - 1; i > 0; i--) {
            const current = trail[i];
            const next = trail[i - 1];

            if (next) {
                const rect = current.getBoundingClientRect();
                const nextRect = next.getBoundingClientRect();

                current.style.left = nextRect.left + 'px';
                current.style.top = nextRect.top + 'px';
            }
        }

        // Update first dot
        if (trail[0]) {
            trail[0].style.left = mouseX - 4 + 'px';
            trail[0].style.top = mouseY - 4 + 'px';
        }

        requestAnimationFrame(updateTrail);
    }

    updateTrail();
}

// Initialize all animations
window.addEventListener('load', () => {
    // Create particle system for hero sections
    document.querySelectorAll('.hero, .emergency-page').forEach(section => {
        new ParticleSystem(section, 30);
    });

    // Split text for animation
    splitTextForAnimation();

    // Animate progress bars
    animateProgressBars();

    // Randomize float animations
    randomizeFloatAnimations();

    // Start gradient shift
    gradientShift();

    // Initialize mouse trail (optional)
    if (window.innerWidth > 768) { // Only on desktop
        initMouseTrail();
    }

    // Remove loading screen
    const preloader = document.getElementById('preloader');
    if (preloader) {
        setTimeout(() => {
            preloader.classList.add('fade-out');
            // Remove from DOM after transition completes
            setTimeout(() => {
                preloader.style.display = 'none';
            }, 500);
        }, 1000); // Show for at least 1 second for better UX
    }
});

// Export for use in other files
window.BedBridgeAnimations = {
    initScrollAnimations,
    initHoverAnimations,
    initPageTransitions,
    initParallaxEffects,
    initTypewriterEffect,
    initCounterAnimations,
    initMagneticButtons,
    initTiltEffect,
    initGlitchEffect,
    ParticleSystem
};