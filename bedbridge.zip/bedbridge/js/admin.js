// Admin Dashboard JavaScript

// API Base URL
const API_BASE_URL = 'http://localhost:5001/api';

// Current hospital ID (in a real app, this would come from authentication)
var currentHospitalId = 1;

document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    loadEmergencyRequests();
    setupAutoUpdate();
    loadHospitalData();
});

function initializeDashboard() {
    console.log('Admin dashboard initialized');
    setupBedCalculations();
}

function setupBedCalculations() {
    var bedTypes = ['icu', 'oxygen', 'vent', 'general'];

    bedTypes.forEach(function(type) {
        var total = document.getElementById(type + '-total');
        var available = document.getElementById(type + '-available');

        if (total && available) {
            total.addEventListener('input', function() {
                calculateOccupied(type);
            });
            available.addEventListener('input', function() {
                calculateOccupied(type);
            });
        }
    });
}

function calculateOccupied(type) {
    var total = document.getElementById(type + '-total');
    var available = document.getElementById(type + '-available');
    var occupied = document.getElementById(type + '-occupied');

    if (total && available && occupied) {
        var totalVal = parseInt(total.value) || 0;
        var availableVal = parseInt(available.value) || 0;
        var occupiedVal = Math.max(0, totalVal - availableVal);

        occupied.value = occupiedVal;
    }
}

// Load hospital data from API
async function loadHospitalData() {
    try {
        var response = await fetch(API_BASE_URL + '/hospitals/' + currentHospitalId);
        if (!response.ok) {
            throw new Error('Failed to fetch hospital data');
        }
        var hospital = await response.json();
        updateHospitalData(hospital);
    } catch (error) {
        console.error('Error loading hospital data:', error);
    }
}

function updateHospitalData(hospital) {
    if (!hospital) return;

    // Update bed inputs
    if (hospital.icu_beds !== undefined) {
        var icuTotal = hospital.icu_beds + Math.floor(Math.random() * 5);
        document.getElementById('icu-total').value = icuTotal;
        document.getElementById('icu-available').value = hospital.icu_beds;
    }
    if (hospital.oxygen_beds !== undefined) {
        var oxygenTotal = hospital.oxygen_beds + Math.floor(Math.random() * 5);
        document.getElementById('oxygen-total').value = oxygenTotal;
        document.getElementById('oxygen-available').value = hospital.oxygen_beds;
    }
    if (hospital.ventilator_beds !== undefined) {
        var ventTotal = hospital.ventilator_beds + Math.floor(Math.random() * 5);
        document.getElementById('vent-total').value = ventTotal;
        document.getElementById('vent-available').value = hospital.ventilator_beds;
    }
    if (hospital.general_beds !== undefined) {
        var generalTotal = hospital.general_beds + Math.floor(Math.random() * 10);
        document.getElementById('general-total').value = generalTotal;
        document.getElementById('general-available').value = hospital.general_beds;
    }

    // Calculate occupied
    calculateOccupied('icu');
    calculateOccupied('oxygen');
    calculateOccupied('vent');
    calculateOccupied('general');

    // Update stats
    updateStatsFromData();
}

function updateBeds() {
    var bedData = {
        icu_beds: parseInt(document.getElementById('icu-available').value) || 0,
        oxygen_beds: parseInt(document.getElementById('oxygen-available').value) || 0,
        ventilator_beds: parseInt(document.getElementById('vent-available').value) || 0,
        general_beds: parseInt(document.getElementById('general-available').value) || 0
    };

    // Show loading state
    var updateBtn = document.querySelector('.update-btn');
    if (!updateBtn) {
        console.error('Update button not found');
        return;
    }
    var originalText = updateBtn.innerHTML;
    updateBtn.innerHTML = '<span class="spinner"></span> Updating...';
    updateBtn.disabled = true;

    // Make API call to update bed data
    fetch(API_BASE_URL + '/hospitals/' + currentHospitalId + '/beds', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bedData)
        })
        .then(function(response) {
            if (!response.ok) {
                throw new Error('Failed to update beds');
            }
            return response.json();
        })
        .then(function(data) {
            console.log('Bed data updated:', data);
            document.getElementById('last-update-time').textContent = 'Just now';
            updateStatsFromData();
            showNotification('Bed availability updated successfully!', 'success');
        })
        .catch(function(error) {
            console.error('Error updating beds:', error);
            showNotification('Error updating bed availability', 'error');
        })
        .finally(function() {
            updateBtn.innerHTML = originalText;
            updateBtn.disabled = false;
        });
}

function updateStatsFromData() {
    var bedTypes = ['icu', 'oxygen', 'vent', 'general'];
    var totalBeds = 0;
    var availableBeds = 0;

    bedTypes.forEach(function(type) {
        var total = parseInt(document.getElementById(type + '-total').value) || 0;
        var available = parseInt(document.getElementById(type + '-available').value) || 0;
        totalBeds += total;
        availableBeds += available;
    });

    var occupiedBeds = totalBeds - availableBeds;
    var utilization = totalBeds > 0 ? Math.round((occupiedBeds / totalBeds) * 100) : 0;

    // Update stat cards
    var statCards = document.querySelectorAll('.stat-card');
    if (statCards[0]) statCards[0].querySelector('.stat-number').textContent = totalBeds;
    if (statCards[1]) statCards[1].querySelector('.stat-number').textContent = occupiedBeds;
    if (statCards[2]) statCards[2].querySelector('.stat-number').textContent = availableBeds;
    if (statCards[3]) statCards[3].querySelector('.stat-number').textContent = utilization + '%';
}

function resetBeds() {
    if (confirm('Reset all bed values to last saved state?')) {
        loadHospitalData();
        showNotification('Values reset to last saved state', 'info');
    }
}

function loadEmergencyRequests() {
    // In a real app, this would fetch from an API
    // For now, we'll show a message
    var tbody = document.getElementById('requests-body');
    if (!tbody) return;

    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;">No pending emergency requests</td></tr>';
}

function handleRequest(patient) {
    console.log('Handling request for:', patient);
    alert('Request details for ' + patient);
}

function setupAutoUpdate() {
    // Auto-refresh data every 30 seconds
    setInterval(function() {
        console.log('Auto-refreshing dashboard data');
        loadHospitalData();
    }, 30000);
}

function showNotification(message, type) {
    type = type || 'info';

    var notification = document.createElement('div');
    notification.className = 'notification glass notification-' + type;
    notification.innerHTML = '<div class="notification-content">' +
        '<span class="notification-icon">' + (type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️') + '</span>' +
        '<p>' + message + '</p>' +
        '</div>';

    document.body.appendChild(notification);

    setTimeout(function() {
        notification.remove();
    }, 3000);
}

// Navigation
var navItems = document.querySelectorAll('.nav-item');
navItems.forEach(function(item) {
    item.addEventListener('click', function(e) {
        e.preventDefault();

        // Remove active class from all
        navItems.forEach(function(nav) {
            nav.classList.remove('active');
        });

        // Add active class to clicked
        item.classList.add('active');

        var view = item.textContent.trim();
        console.log('Switching to view:', view);
    });
});

// Make functions globally available
window.updateBeds = updateBeds;
window.resetBeds = resetBeds;