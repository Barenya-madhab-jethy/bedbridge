from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from math import radians, sin, cos, sqrt, atan2
import os

app = Flask(__name__)
CORS(app)

# Get the base directory (parent of backend folder)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Configure static folder
app.static_folder = os.path.join(BASE_DIR)
app.template_folder = BASE_DIR

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bedbridge.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


def haversine_km(lat1, lon1, lat2, lon2):
    """Calculate distance between coordinates in kilometers."""
    earth_radius_km = 6371
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    lat1_rad = radians(lat1)
    lat2_rad = radians(lat2)

    a = sin(dlat / 2) ** 2 + cos(lat1_rad) * cos(lat2_rad) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return earth_radius_km * c

# Hospital Model
class Hospital(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    address = db.Column(db.String(500), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    icu_beds = db.Column(db.Integer, default=0)
    oxygen_beds = db.Column(db.Integer, default=0)
    ventilator_beds = db.Column(db.Integer, default=0)
    general_beds = db.Column(db.Integer, default=0)
    last_update = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'address': self.address,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'phone': self.phone,
            'icu_beds': self.icu_beds,
            'oxygen_beds': self.oxygen_beds,
            'ventilator_beds': self.ventilator_beds,
            'general_beds': self.general_beds,
            'last_update': self.last_update.isoformat()
        }

# Routes
@app.route('/api/hospitals', methods=['GET'])
def get_hospitals():
    hospitals = Hospital.query.all()
    return jsonify([h.to_dict() for h in hospitals])

@app.route('/api/hospitals/nearby', methods=['GET'])
def get_nearby_hospitals():
    lat = request.args.get('lat', type=float)
    lon = request.args.get('lon', type=float)
    radius = request.args.get('radius', 10, type=float)

    if lat is None or lon is None:
        return jsonify({'error': 'lat and lon query parameters are required'}), 400
    if radius is None or radius <= 0:
        return jsonify({'error': 'radius must be a positive number'}), 400
    
    # Calculate distance using Haversine formula
    hospitals = Hospital.query.all()
    
    def calculate_distance(h):
        return haversine_km(lat, lon, h.latitude, h.longitude)
    
    nearby = []
    for hospital in hospitals:
        distance = calculate_distance(hospital)
        if distance <= radius:
            hospital_dict = hospital.to_dict()
            hospital_dict['distance'] = round(distance, 2)
            nearby.append(hospital_dict)
    
    # Sort by distance
    nearby.sort(key=lambda x: x['distance'])
    
    return jsonify(nearby)

@app.route('/api/hospitals/<int:hospital_id>', methods=['GET'])
def get_hospital(hospital_id):
    hospital = Hospital.query.get_or_404(hospital_id)
    return jsonify(hospital.to_dict())

@app.route('/api/hospitals/<int:hospital_id>/beds', methods=['PUT'])
def update_beds(hospital_id):
    hospital = Hospital.query.get_or_404(hospital_id)
    data = request.get_json(silent=True) or {}

    if not data:
        return jsonify({'error': 'Request body must be valid JSON'}), 400

    allowed_fields = {'icu_beds', 'oxygen_beds', 'ventilator_beds', 'general_beds'}
    for field in allowed_fields:
        if field in data:
            value = data[field]
            if not isinstance(value, int) or value < 0:
                return jsonify({'error': f'{field} must be a non-negative integer'}), 400
            setattr(hospital, field, value)
    
    hospital.last_update = datetime.utcnow()
    db.session.commit()
    
    return jsonify(hospital.to_dict())

@app.route('/api/emergency', methods=['POST'])
def emergency_request():
    data = request.get_json(silent=True) or {}
    lat = data.get('latitude')
    lon = data.get('longitude')
    bed_type = data.get('bed_type', 'icu')

    if lat is None or lon is None:
        return jsonify({'error': 'latitude and longitude are required'}), 400

    try:
        lat = float(lat)
        lon = float(lon)
    except (TypeError, ValueError):
        return jsonify({'error': 'latitude and longitude must be numbers'}), 400

    valid_bed_types = {'icu', 'oxygen', 'ventilator', 'general'}
    if bed_type not in valid_bed_types:
        return jsonify({'error': 'bed_type must be one of: icu, oxygen, ventilator, general'}), 400
    
    # Find nearest hospital with required bed type
    hospitals = Hospital.query.all()
    
    def has_required_beds(h):
        if bed_type == 'icu':
            return h.icu_beds > 0
        elif bed_type == 'oxygen':
            return h.oxygen_beds > 0
        elif bed_type == 'ventilator':
            return h.ventilator_beds > 0
        else:
            return h.general_beds > 0
    
    available_hospitals = [h for h in hospitals if has_required_beds(h)]
    
    if not available_hospitals:
        return jsonify({'error': 'No beds available'}), 404
    
    # Calculate distance using consistent geodesic logic
    def calculate_distance(h):
        return haversine_km(lat, lon, h.latitude, h.longitude)
    
    nearest = min(available_hospitals, key=calculate_distance)
    
    return jsonify({
        'hospital': nearest.to_dict(),
        'distance': round(calculate_distance(nearest), 2)
    })

# Add sample data function
def add_sample_data():
    """Add sample hospital data to the database"""
    # Check if data already exists
    if Hospital.query.first():
        return
    
    sample_hospitals = [
        Hospital(
            name="All India Institute of Medical Sciences (AIIMS)",
            address="Ansari Nagar, New Delhi, Delhi 110029",
            latitude=28.5921,
            longitude=77.1945,
            phone="+91-11-26594400",
            icu_beds=50,
            oxygen_beds=100,
            ventilator_beds=30,
            general_beds=200
        ),
        Hospital(
            name="Safdarjung Hospital",
            address="Ring Road, New Delhi, Delhi 110029",
            latitude=28.5897,
            longitude=77.1925,
            phone="+91-11-26730000",
            icu_beds=30,
            oxygen_beds=60,
            ventilator_beds=20,
            general_beds=150
        ),
        Hospital(
            name="Ram Manohar Lohia Hospital",
            address="Baba Kharak Singh Marg, New Delhi, Delhi 110001",
            latitude=28.6315,
            longitude=77.1965,
            phone="+91-11-23365525",
            icu_beds=25,
            oxygen_beds=50,
            ventilator_beds=15,
            general_beds=120
        ),
        Hospital(
            name="Lady Hardinge Medical College",
            address="Connaught Place, New Delhi, Delhi 110001",
            latitude=28.6310,
            longitude=77.2095,
            phone="+91-11-23363728",
            icu_beds=20,
            oxygen_beds=40,
            ventilator_beds=10,
            general_beds=100
        ),
        Hospital(
            name="GTB Hospital",
            address="Geeta Colony, East Delhi, Delhi 110031",
            latitude=28.6522,
            longitude=77.2674,
            phone="+91-11-22252002",
            icu_beds=35,
            oxygen_beds=70,
            ventilator_beds=25,
            general_beds=180
        ),
        Hospital(
            name="Rajiv Gandhi Super Speciality Hospital",
            address="Tahirpur, Delhi 110093",
            latitude=28.6860,
            longitude=77.2980,
            phone="+91-11-22112121",
            icu_beds=40,
            oxygen_beds=80,
            ventilator_beds=22,
            general_beds=160
        ),
        Hospital(
            name="Baba Saheb Ambedkar Hospital",
            address="Rohini, Sector 6, Delhi 110085",
            latitude=28.7409,
            longitude=77.0724,
            phone="+91-11-27055585",
            icu_beds=28,
            oxygen_beds=55,
            ventilator_beds=18,
            general_beds=140
        ),
        Hospital(
            name="Deen Dayal Upadhyay Hospital",
            address="Hari Nagar, New Delhi, Delhi 110064",
            latitude=28.6254,
            longitude=77.1173,
            phone="+91-11-25494433",
            icu_beds=22,
            oxygen_beds=45,
            ventilator_beds=12,
            general_beds=110
        ),
        Hospital(
            name="Sanjay Gandhi Memorial Hospital",
            address="Mangol Puri, New Delhi, Delhi 110083",
            latitude=28.6978,
            longitude=77.0726,
            phone="+91-11-27921033",
            icu_beds=18,
            oxygen_beds=35,
            ventilator_beds=8,
            general_beds=90
        ),
        Hospital(
            name="Indira Gandhi ESI Hospital",
            address="Jhilmil, Delhi 110095",
            latitude=28.6757,
            longitude=77.3385,
            phone="+91-11-22159513",
            icu_beds=15,
            oxygen_beds=30,
            ventilator_beds=8,
            general_beds=80
        ),
        Hospital(
            name="Maharaja Agrasen Hospital",
            address="Punjabi Bagh, New Delhi, Delhi 110026",
            latitude=28.6700,
            longitude=77.1280,
            phone="+91-11-40779000",
            icu_beds=25,
            oxygen_beds=50,
            ventilator_beds=15,
            general_beds=130
        )
    ]
    
    db.session.add_all(sample_hospitals)
    db.session.commit()
    print("Sample hospital data added successfully!")

# Static file serving routes
@app.route('/')
def index():
    """Serve the main index.html page"""
    return send_from_directory(BASE_DIR, 'index.html')

@app.route('/emergency.html')
def emergency():
    """Serve the emergency.html page"""
    return send_from_directory(BASE_DIR, 'emergency.html')

@app.route('/search.html')
def search():
    """Serve the search.html page"""
    return send_from_directory(BASE_DIR, 'search.html')

@app.route('/admin/<path:filename>')
def admin_static(filename):
    """Serve admin static files"""
    return send_from_directory(os.path.join(BASE_DIR, 'admin'), filename)

@app.route('/css/<path:filename>')
def css_static(filename):
    """Serve CSS files"""
    return send_from_directory(os.path.join(BASE_DIR, 'css'), filename)

@app.route('/js/<path:filename>')
def js_static(filename):
    """Serve JS files"""
    return send_from_directory(os.path.join(BASE_DIR, 'js'), filename)

@app.route('/assets/<path:filename>')
def assets_static(filename):
    """Serve asset files"""
    return send_from_directory(os.path.join(BASE_DIR, 'assets'), filename)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        add_sample_data()
    app.run(debug=True, port=5001)
