-- BedBridge Database Schema

-- Create database
CREATE DATABASE IF NOT EXISTS bedbridge;
USE bedbridge;

-- Hospitals table
CREATE TABLE hospitals (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    address VARCHAR(500) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    website VARCHAR(200),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Bed availability table
CREATE TABLE bed_availability (
    id INT PRIMARY KEY AUTO_INCREMENT,
    hospital_id INT NOT NULL,
    bed_type ENUM('ICU', 'OXYGEN', 'VENTILATOR', 'GENERAL') NOT NULL,
    total_beds INT NOT NULL,
    available_beds INT NOT NULL,
    occupied_beds INT NOT NULL,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by VARCHAR(100),
    FOREIGN KEY (hospital_id) REFERENCES hospitals(id),
    INDEX idx_hospital_bed (hospital_id, bed_type)
);

-- Emergency requests table
CREATE TABLE emergency_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_name VARCHAR(100),
    patient_age INT,
    emergency_type VARCHAR(100),
    bed_type_required VARCHAR(50),
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    location_address VARCHAR(500),
    hospital_id INT,
    status ENUM('PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED') DEFAULT 'PENDING',
    request_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    response_time TIMESTAMP NULL,
    completion_time TIMESTAMP NULL,
    FOREIGN KEY (hospital_id) REFERENCES hospitals(id),
    INDEX idx_status (status),
    INDEX idx_request_time (request_time)
);

-- Hospital staff table
CREATE TABLE hospital_staff (
    id INT PRIMARY KEY AUTO_INCREMENT,
    hospital_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('ADMIN', 'STAFF', 'DOCTOR') DEFAULT 'STAFF',
    phone VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hospital_id) REFERENCES hospitals(id)
);

-- Bed update history table
CREATE TABLE bed_update_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    hospital_id INT NOT NULL,
    bed_type VARCHAR(50) NOT NULL,
    previous_available INT,
    new_available INT,
    updated_by INT,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hospital_id) REFERENCES hospitals(id),
    FOREIGN KEY (updated_by) REFERENCES hospital_staff(id),
    INDEX idx_hospital_time (hospital_id, update_time)
);

-- Sample data insertion
INSERT INTO hospitals (name, address, latitude, longitude, phone) VALUES
('City General Hospital', '123 Main St, New York, NY', 40.7128, -74.0060, '+1-212-555-0123'),
('St. Mary\'s Medical Center', '456 Park Ave, New York, NY', 40.7614, -73.9776, '+1-212-555-0456'),
('University Hospital', '789 College Rd, New York, NY', 40.7295, -73.9965, '+1-212-555-0789');

INSERT INTO bed_availability (hospital_id, bed_type, total_beds, available_beds, occupied_beds) VALUES
(1, 'ICU', 20, 5, 15),
(1, 'OXYGEN', 30, 8, 22),
(1, 'VENTILATOR', 15, 3, 12),
(1, 'GENERAL', 100, 25, 75),
(2, 'ICU', 15, 2, 13),
(2, 'OXYGEN', 25, 4, 21),
(2, 'VENTILATOR', 10, 1, 9),
(2, 'GENERAL', 80, 15, 65),
(3, 'ICU', 25, 8, 17),
(3, 'OXYGEN', 35, 12, 23),
(3, 'VENTILATOR', 20, 5, 15),
(3, 'GENERAL', 120, 30, 90);

-- Create indexes for performance
CREATE INDEX idx_location ON hospitals(latitude, longitude);
CREATE INDEX idx_bed_availability ON bed_availability(available_beds);
CREATE INDEX idx_emergency_location ON emergency_requests(latitude, longitude);

-- Create view for real-time bed availability
CREATE VIEW vw_real_time_beds AS
SELECT 
    h.id,
    h.name,
    h.address,
    h.latitude,
    h.longitude,
    h.phone,
    MAX(CASE WHEN b.bed_type = 'ICU' THEN b.available_beds END) as icu_beds,
    MAX(CASE WHEN b.bed_type = 'OXYGEN' THEN b.available_beds END) as oxygen_beds,
    MAX(CASE WHEN b.bed_type = 'VENTILATOR' THEN b.available_beds END) as ventilator_beds,
    MAX(CASE WHEN b.bed_type = 'GENERAL' THEN b.available_beds END) as general_beds,
    MAX(b.last_updated) as last_update
FROM hospitals h
LEFT JOIN bed_availability b ON h.id = b.hospital_id
GROUP BY h.id, h.name, h.address, h.latitude, h.longitude, h.phone;

-- Stored procedure for emergency bed search
DELIMITER //
CREATE PROCEDURE FindEmergencyBed(
    IN p_latitude DECIMAL(10,8),
    IN p_longitude DECIMAL(11,8),
    IN p_bed_type VARCHAR(50),
    IN p_radius_km INT
)
BEGIN
    SELECT 
        h.*,
        b.available_beds,
        (6371 * acos(cos(radians(p_latitude)) * cos(radians(h.latitude)) * cos(radians(h.longitude) - radians(p_longitude)) + sin(radians(p_latitude)) * sin(radians(h.latitude)))) AS distance
    FROM hospitals h
    JOIN bed_availability b ON h.id = b.hospital_id
    WHERE b.bed_type = p_bed_type 
    AND b.available_beds > 0
    HAVING distance < p_radius_km
    ORDER BY distance ASC
    LIMIT 1;
END //
DELIMITER ;

-- Trigger for bed update logging
DELIMITER //
CREATE TRIGGER after_bed_update
AFTER UPDATE ON bed_availability
FOR EACH ROW
BEGIN
    IF OLD.available_beds != NEW.available_beds THEN
        INSERT INTO bed_update_history (hospital_id, bed_type, previous_available, new_available, updated_by)
        VALUES (NEW.hospital_id, NEW.bed_type, OLD.available_beds, NEW.available_beds, NEW.updated_by);
    END IF;
END //
DELIMITER ;